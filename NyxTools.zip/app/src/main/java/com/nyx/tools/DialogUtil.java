package com.nyx.tools;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;

public class DialogUtil {

        // Fungsi utama tombol kembali yang adil untuk Android 11 s.d 16+
    public static void registerExitDialog(final Activity activity) {
        if (android.os.Build.VERSION.SDK_INT >= 35) {
            // 🔥 KHUSUS ANDROID 15 & 16+ (Target API 36)
            activity.getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                new android.window.OnBackInvokedCallback() {
                    @Override
                    public void onBackInvoked() {
                        showCustomExitDialog(activity);
                    }
                }
            );
        } else {
            // 🔒 KHUSUS ANDROID 14 KE BAWAH (Mencegah Tombol Back Macet)
            // Kita biarkan sistem OS lama berjalan normal menggunakan metode bawaan Activity
            // Anda TIDAK PERLU menghapus kode ini, kodenya otomatis mendeteksi sendiri.
        }
    }

    // Fungsi internal untuk menampilkan struktur dialog kustom Anda
    public static void showCustomExitDialog(final Activity activity) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        LayoutInflater inflater = activity.getLayoutInflater();
        
        // Mengambil layout dialog kustom dari resource aplikasi
        int layoutId = activity.getResources().getIdentifier("dialogexit", "layout", activity.getPackageName());
        View dialogView = inflater.inflate(layoutId, null);
        builder.setView(dialogView);

        final AlertDialog dialog = builder.create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        // Mencari ID tombol secara dinamis agar tidak eror di class terpisah
        int cancelId = activity.getResources().getIdentifier("btnCancel", "id", activity.getPackageName());
        int exitId = activity.getResources().getIdentifier("btnExit", "id", activity.getPackageName());
        
        Button btnCancel = dialogView.findViewById(cancelId);
        Button btnExit = dialogView.findViewById(exitId);

        // ---- Animasi tekan-tahan untuk Cancel ----
        btnCancel.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(100).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
                        break;
                }
                return false;
            }
        });

        // ---- Animasi tekan-tahan untuk Exit ----
        btnExit.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(100).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
                        break;
                }
                return false;
            }
        });

        // ---- Aksi klik tombol ----
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.finishAffinity(); // Keluar total dari aplikasi
            }
        });

        dialog.show();

        // ---- Animasi zoom masuk ----
        int animId = activity.getResources().getIdentifier("dialog_scale_in", "anim", activity.getPackageName());
        if (animId != 0) {
            Animation zoomIn = AnimationUtils.loadAnimation(activity, animId);
            dialogView.startAnimation(zoomIn);
        }
    }
    
           public static void applySecureEdgeToEdge(final Activity activity) {
        // Paksa ikon status bar & navigation bar tetap berwarna PUTIH (Light icons on dark background)
        if (activity instanceof androidx.activity.ComponentActivity) {
            androidx.activity.EdgeToEdge.enable(
                (androidx.activity.ComponentActivity) activity,
                androidx.activity.SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
                androidx.activity.SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
            );
        }

        if (android.os.Build.VERSION.SDK_INT >= 30) {
            if (android.os.Build.VERSION.SDK_INT >= 34) {
                activity.getWindow().setDecorFitsSystemWindows(true);
            } else {
                activity.getWindow().setDecorFitsSystemWindows(false);
            }
            
            // Jalankan pengaturan warna HANYA di bawah Android 15 (API < 35)
            if (android.os.Build.VERSION.SDK_INT < 35) {
                activity.getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);
                activity.getWindow().setNavigationBarColor(android.graphics.Color.TRANSPARENT);
                
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    activity.getWindow().setStatusBarContrastEnforced(false);
                    activity.getWindow().setNavigationBarContrastEnforced(false);
                }
            }
        }

        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(
            activity.findViewById(android.R.id.content),
            new androidx.core.view.OnApplyWindowInsetsListener() {
                @Override
                public androidx.core.view.WindowInsetsCompat onApplyWindowInsets(View v, androidx.core.view.WindowInsetsCompat insets) {
                    final androidx.core.graphics.Insets bars = insets.getInsets(
                        androidx.core.view.WindowInsetsCompat.Type.systemBars()
                    );

                    // Mengamankan root container berdasarkan versi Android
                    if (android.os.Build.VERSION.SDK_INT >= 34) {
                        // KODE ASLI ANDA: Untuk Android 14, 15, dan Android 16+
                        v.setPadding(0, 0, 0, -bars.bottom);
                    } else {
                        // KODE PERBAIKAN: Untuk Android 13 kebawah agar container dasar melar penuh tanpa memotong konten layout di atasnya
                        v.setPadding(0, 0, 0, 0);
                    }

                    // 🔥 KHUSUS HALAMAN PERTAMA (MainActivity): Paksa turunkan AppBar kaku Sketchware
                    if (activity.getClass().getSimpleName().equals("MainActivity")) {
                        final View appBarView = activity.findViewById(
                            activity.getResources().getIdentifier("appbar", "id", activity.getPackageName())
                        );
                        
                        if (appBarView != null) {
                            appBarView.post(new Runnable() {
                                @Override
                                public void run() {
                                    int currentHeight = appBarView.getHeight();
                                    if (appBarView.getPaddingTop() < bars.top) {
                                        appBarView.setPadding(appBarView.getPaddingLeft(), bars.top, appBarView.getPaddingRight(), appBarView.getPaddingBottom());
                                        
                                        android.view.ViewGroup.LayoutParams lp = appBarView.getLayoutParams();
                                        if (lp != null && currentHeight > 0) {
                                            lp.height = currentHeight + bars.top;
                                            appBarView.setLayoutParams(lp);
                                        }
                                    }
                                }
                            });
                        }
                    }

                    // 2. BERSIHKAN KOMPONEN LIST (GridView / ListView / RecyclerView) Di Semua Halaman
                    final String[] listIds = {"gridview1", "listview1", "recyclerview1"};
                    for (String id : listIds) {
                        final View targetList = activity.findViewById(
                            activity.getResources().getIdentifier(id, "id", activity.getPackageName())
                        );
                        
                        if (targetList != null) {
                            if (android.os.Build.VERSION.SDK_INT >= 34) {
                                // Kode asli Anda untuk Android modern
                                targetList.setPadding(targetList.getPaddingLeft(), targetList.getPaddingTop(), targetList.getPaddingRight(), 0);
                            } else {
                                // Khusus Android 13 kebawah: padding bawah list diberi tinggi navigation bar asli agar konten terbawah bisa di-scroll melewati tombol sistem
                                targetList.setPadding(targetList.getPaddingLeft(), targetList.getPaddingTop(), targetList.getPaddingRight(), bars.bottom);
                            }
                            
                            if (targetList.getLayoutParams() instanceof android.view.ViewGroup.MarginLayoutParams) {
                                android.view.ViewGroup.MarginLayoutParams marginParams = 
                                    (android.view.ViewGroup.MarginLayoutParams) targetList.getLayoutParams();
                                marginParams.bottomMargin = 0;
                                targetList.setLayoutParams(marginParams);
                            }
                            
                            if (targetList instanceof android.widget.GridView) {
                                ((android.widget.GridView) targetList).setClipToPadding(false);
                            } else if (targetList instanceof android.widget.ListView) {
                                ((android.widget.ListView) targetList).setClipToPadding(false);
                            } else if (targetList instanceof androidx.recyclerview.widget.RecyclerView) {
                                ((androidx.recyclerview.widget.RecyclerView) targetList).setClipToPadding(false);
                            }
                            break;
                        }
                    }

                    return insets;
                }
            }
        );
    }
}