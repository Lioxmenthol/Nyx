package com.nyx.tools;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.TransitionDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class SplashScreenActivity extends AppCompatActivity {

    private Timer _timer = new Timer();
    private TimerTask t;
    private ParticleView particleView;
    private CyberElectricView electricIconView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // ================================================================
        // FULL BACKGROUND UNTUK ANDROID 10+ TANPA IMMERSIVE
        // Status bar dan navigation bar tetap tampil,
        // tetapi background Activity berada di belakangnya.
        // ================================================================
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {

            getWindow().addFlags(
                    android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS
            );

            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().setNavigationBarColor(Color.TRANSPARENT);

            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            );
        }

        // Android 10 / API 29
        // Matikan contrast enforcement agar navigation bar tidak diberi
        // background putih/abu-abu otomatis oleh sistem.
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }

        // Kunci penanda agar iklan open tidak menyerobot di awal
        AnehApplication.isSplashActive = true;

        float density = getResources().getDisplayMetrics().density;

        // ===== 1. ROOT CONTAINER (FRAME LAYOUT) =====
        FrameLayout rootFrame = new FrameLayout(this);
        rootFrame.setBackgroundColor(Color.parseColor("#4A148C"));

        // ===== 2. BACKGROUND GRADASI BERPUTAR =====
        LinearLayout backgroundView = new LinearLayout(this);
        FrameLayout.LayoutParams bgLp = new FrameLayout.LayoutParams(
                (int) (getResources().getDisplayMetrics().widthPixels * 1.8),
                (int) (getResources().getDisplayMetrics().heightPixels * 1.8)
        );
        bgLp.gravity = Gravity.CENTER;
        backgroundView.setLayoutParams(bgLp);

        GradientDrawable warnaAwal = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.parseColor("#4A148C"), Color.parseColor("#1A237E")}
        );
        GradientDrawable warnaAkhir = new GradientDrawable(
                GradientDrawable.Orientation.BR_TL,
                new int[]{Color.parseColor("#6A1B9A"), Color.parseColor("#311B92")}
        );
        TransitionDrawable bgTransisi = new TransitionDrawable(new GradientDrawable[]{warnaAwal, warnaAkhir});
        backgroundView.setBackground(bgTransisi);
        rootFrame.addView(backgroundView);

        // Jalankan animasi rotasi berputar lambat secara konstan pada background
        backgroundView.animate()
                .rotation(360f)
                .setDuration(12000)
                .setInterpolator(new android.view.animation.LinearInterpolator())
                .setListener(new android.animation.AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(android.animation.Animator animation) {
                        backgroundView.setRotation(0f);
                        backgroundView.animate().rotation(360f).setDuration(12000).setInterpolator(new android.view.animation.LinearInterpolator()).start();
                    }
                }).start();
        bgTransisi.startTransition(2500);

        // ===== 3. EFEK PARTIKEL KUSTOM =====
        particleView = new ParticleView(this);
        rootFrame.addView(particleView);

                 // ===== 4. CONTAINER KONTEN UTAMA (LOGO CYBER & TEXT) =====
        LinearLayout animContainer = new LinearLayout(this);
        animContainer.setOrientation(LinearLayout.VERTICAL);
        animContainer.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams containerLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        animContainer.setLayoutParams(containerLp);
        
        // Posisi awal konten super kecil untuk efek letupan (Zoom-In)
        animContainer.setAlpha(0f);
        animContainer.setScaleX(0.1f);
        animContainer.setScaleY(0.1f);

        // ICON LOGO DENGAN ANIMASI ELEKTRIK CYBERPUNK
        electricIconView = new CyberElectricView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams((int) (165 * density), (int) (165 * density));
        electricIconView.setLayoutParams(lp);
        animContainer.addView(electricIconView);

        // ===== TEKS NAMA APLIKASI UTAMA =====
        TextView introText = new TextView(this);
        LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        textLp.topMargin = (int) (15 * density);
        introText.setLayoutParams(textLp);
        introText.setText("Nyx Tools");
        introText.setTextSize(32); 
        introText.setTextColor(Color.WHITE);
        introText.setGravity(Gravity.CENTER);
        
        // 🌟 DIUBAH KE MONOSPACE BOLD: Font mesin terminal digital yang tebal khas cyber
        introText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        animContainer.addView(introText);

        // TEKS SUB-DESKRIPSI (Zero Tools Skin Detail Hero | Visual Skin | Equipment Guide)
        TextView subIntroText = new TextView(this);
        LinearLayout.LayoutParams subTextLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        subTextLp.topMargin = (int) (6 * density);
        subIntroText.setLayoutParams(subTextLp);
        subIntroText.setText("Detail Hero | Equipment Guide | WinRate Calculator");
        subIntroText.setTextSize(12); // Dibuat sedikit lebih kecil agar proporsional
        subIntroText.setTextColor(Color.parseColor("#B39DDB")); 
        subIntroText.setGravity(Gravity.CENTER);
        
        // 🌟 DIUBAH KE MONOSPACE NORMAL: Konsisten dengan tema cyber terminal data
        subIntroText.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        animContainer.addView(subIntroText);

        rootFrame.addView(animContainer);

        // ================================================================
        // 🌟 KOMPONEN PREMIUM: CYBER PROGRESS LAYOUT (GAYA GS TOOLS)
        // ================================================================
        LinearLayout cyberProgressArea = new LinearLayout(this);
        cyberProgressArea.setOrientation(LinearLayout.VERTICAL);
        cyberProgressArea.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout.LayoutParams progressAreaLp = new FrameLayout.LayoutParams(
                (int) (260 * density), FrameLayout.LayoutParams.WRAP_CONTENT); 
        progressAreaLp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        progressAreaLp.bottomMargin = (int) (40 * density);
        cyberProgressArea.setLayoutParams(progressAreaLp);

        // 1. Garis Progress Bar Tipis Kustom (Track)
        FrameLayout barTrackFrame = new FrameLayout(this);
        LinearLayout.LayoutParams trackLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (int) (3 * density)); 
        trackLp.bottomMargin = (int) (8 * density);
        barTrackFrame.setLayoutParams(trackLp);
        
        GradientDrawable trackDrawable = new GradientDrawable();
        trackDrawable.setColor(Color.parseColor("#33FFFFFF"));
        trackDrawable.setCornerRadius(4 * density);
        barTrackFrame.setBackground(trackDrawable);

        // 2. Garis Isi Progress (The Running Fill Line)
        View barFillView = new View(this);
        FrameLayout.LayoutParams fillLp = new FrameLayout.LayoutParams(
                0, FrameLayout.LayoutParams.MATCH_PARENT); 
        barFillView.setLayoutParams(fillLp);
        
        GradientDrawable fillDrawable = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.parseColor("#00E5FF"), Color.parseColor("#E040FB")}
        );
        fillDrawable.setCornerRadius(4 * density);
        barFillView.setBackground(fillDrawable);
        barTrackFrame.addView(barFillView);
        cyberProgressArea.addView(barTrackFrame);

        // 3. Teks Info Log Status & Angka Persen di Bawah Bar
        TextView txtLoading = new TextView(this);
        LinearLayout.LayoutParams loadingTextLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        txtLoading.setLayoutParams(loadingTextLp);
        txtLoading.setText("Connecting to server... (0%)");
        txtLoading.setTextSize(11);
        txtLoading.setTextColor(Color.WHITE);
        txtLoading.setAlpha(0.75f);
        
        // 🌟 DIUBAH KE MONOSPACE BOLD KECIL: Menampilkan log sirkuit mirip running code terminal
        txtLoading.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        cyberProgressArea.addView(txtLoading);

        rootFrame.addView(cyberProgressArea);
        setContentView(rootFrame);

        // JALANKAN EFEK PERCIKAN LETUPAN (ZOOM IN) KONTEN UTAMA
        animContainer.animate()
                .alpha(1f)
                .scaleX(1.0f)
                .scaleY(1.0f)
                .setDuration(1200)
                .setInterpolator(new android.view.animation.OvershootInterpolator(2.8f))
                .start();

                // ================================================================
        // 🌟 ENGINE SIMULASI KINETIK PROGRESS REALTIME (FIXED COMPILER)
        // ================================================================
        final int maxBarWidth = (int) (260 * density); 
        final int[] progressVal = {0}; // Berupa array tunggal untuk ditembus anonymous class
        
        final String[] statusTexts = {
                "Connecting to server...", 
                "Fetching resources...", 
                "Optimizing asset engine...", 
                "Securing gateway content...", 
                "Success (100%)"
        };
        
        final android.os.Handler loadingHandler = new android.os.Handler();
        Runnable loadingRunnable = new Runnable() {
            @Override
            public void run() {
                // Gunakan [0] agar dibaca sebagai tipe data primitive int biasa oleh Java
                if (progressVal[0] < 100) {
                    progressVal[0] += 2 + new Random().nextInt(7);
                    if (progressVal[0] > 100) progressVal[0] = 100;
                    
                    // Update lebar isi bar mengikuti kalkulasi angka persen saat ini
                    FrameLayout.LayoutParams dynamicFill = (FrameLayout.LayoutParams) barFillView.getLayoutParams();
                    dynamicFill.width = (int) (maxBarWidth * (progressVal[0] / 100.0f));
                    barFillView.setLayoutParams(dynamicFill);
                    
                    // Alokasi penunjuk indeks string teks status [0-4] berdasarkan persentase
                    String currentStatus = statusTexts[0];
                    if (progressVal[0] > 20 && progressVal[0] <= 50) {
                        currentStatus = statusTexts[1];
                    } else if (progressVal[0] > 50 && progressVal[0] <= 75) {
                        currentStatus = statusTexts[2];
                    } else if (progressVal[0] > 75 && progressVal[0] < 100) {
                        currentStatus = statusTexts[3];
                    } else if (progressVal[0] == 100) {
                        currentStatus = statusTexts[4];
                    }

                    txtLoading.setText(currentStatus + " (" + progressVal[0] + "%)");
                    
                    // Jalankan interval fluktuasi pemuatan data cyber
                    loadingHandler.postDelayed(this, 130 + new Random().nextInt(130));
                }
            }
        };
        loadingHandler.post(loadingRunnable);



        // ===== 5. TIMER TRANSISI KELUAR (ZOOM-IN EXIT KELUAR MENEMBUS MATRA) =====
        t = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        rootFrame.animate()
                                .alpha(0f)
                                .scaleX(3.0f) // Meledak membesar menembus layar luar ke depan
                                .scaleY(3.0f)
                                .setDuration(450) 
                                .setInterpolator(new android.view.animation.AccelerateInterpolator())
                                .setListener(new android.animation.AnimatorListenerAdapter() {
                                    @Override
                                    public void onAnimationEnd(android.animation.Animator animation) {
                                        if (particleView != null) {
                                            particleView.stopParticles();
                                        }

                                        // 🔓 Buka saklar agar OpenAd wajib tayang
                                        AnehApplication.isSplashActive = false;

                                        // 🚀 Tembak Iklan Open sebelum masuk ke MainActivity
                                        if (getApplication() instanceof AnehApplication) {
                                            AnehApplication app = (AnehApplication) getApplication();
                                            if (app.getAppOpenManager() != null) {
                                                app.getAppOpenManager().showAdWithCallback(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        Intent intent = new Intent(SplashScreenActivity.this, MainActivity.class);
                                                        startActivity(intent);
                                                        
                                                        // Matikan sistem slide bawaan Android 16
                                                        overridePendingTransition(0, 0);
                                                        finish();
                                                    }
                                                });
                                                return; 
                                            }
                                        }

                                        // Alur cadangan jika AdMob null
                                        Intent intent = new Intent(SplashScreenActivity.this, MainActivity.class);
                                        startActivity(intent);
                                        overridePendingTransition(0, 0);
                                        finish();
                                    }
                                }).start();
                    }
                });
            }
        };
        // 🌟 DIUBAH KE 4500ms (4.5 DETIK): Menjamin teks loading menyentuh angka 100% dan transisi berjalan pas
        _timer.schedule(t, 5000); 
    }


    // ===== 👑 CLASS INTERNAL 1: CUSTOM VIEW LOGO BERIKAT LISTRIK CYBER =====
    private static class CyberElectricView extends FrameLayout {
        private final ImageView actualLogo;
        private final Paint electricPaint = new Paint();
        private final Paint glowPaint = new Paint();
        private final Path boltPath = new Path();
        private final Random rand = new Random();
        private final float density;

        public CyberElectricView(Context context) {
            super(context);
            setWillNotDraw(false);
            density = getResources().getDisplayMetrics().density;

            // Inisialisasi Logo Utama di Tengah
            actualLogo = new ImageView(context);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) (130 * density), (int) (130 * density));
            lp.gravity = Gravity.CENTER;
            actualLogo.setLayoutParams(lp);
            actualLogo.setImageResource(R.drawable.zero);
            actualLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);
            addView(actualLogo);

            // Setup Paint Inti Listrik (Cyan Cyber Neon)
            electricPaint.setColor(Color.parseColor("#00E5FF"));
            electricPaint.setStyle(Paint.Style.STROKE);
            electricPaint.setStrokeWidth(2f * density);
            electricPaint.setAntiAlias(true);

            // Setup Paint Efek Cahaya Pendar Listrik (Glow Outer)
            glowPaint.setColor(Color.parseColor("#00B0FF"));
            glowPaint.setStyle(Paint.Style.STROKE);
            glowPaint.setStrokeWidth(5f * density);
            glowPaint.setAlpha(120);
            glowPaint.setAntiAlias(true);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float radius = (130 * density) / 2f;

            for (int i = 0; i < 3; i++) {
                generateCircularLightning(cx, cy, radius);
                canvas.drawPath(boltPath, glowPaint);     
                canvas.drawPath(boltPath, electricPaint); 
            }
            invalidate(); // Redraw konstan untuk kedipan kilat elektrik dinamis
        }

        private void generateCircularLightning(float cx, float cy, float r) {
            boltPath.reset();
            int points = 24; 
            float angleStep = (float) (2 * Math.PI / points);

            for (int i = 0; i <= points; i++) {
                float currentAngle = i * angleStep;
                float offset = -8 * density + rand.nextFloat() * (16 * density);
                float dynamicRadius = r + offset;

                float x = cx + (float) (Math.cos(currentAngle) * dynamicRadius);
                float y = cy + (float) (Math.sin(currentAngle) * dynamicRadius);

                if (i == 0) {
                    boltPath.moveTo(x, y);
                } else {
                    boltPath.lineTo(x, y);
                }
            }
            boltPath.close();
        }
    }

    // ===== 👑 CLASS INTERNAL 2: GENERATOR PARTIKEL BACKGROUND =====
    private static class ParticleView extends View {
        private final List<Particle> particles = new ArrayList<>();
        private final Random random = new Random();
        private final Paint paint = new Paint();
        private boolean isRunning = true;

        public ParticleView(Context context) {
            super(context);
            paint.setAntiAlias(true);
            for (int i = 0; i < 35; i++) {
                particles.add(new Particle());
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (!isRunning) return;

            int width = getWidth();
            int height = getHeight();

            if (width == 0 || height == 0) {
                invalidate();
                return;
            }

            for (Particle p : particles) {
                p.update(width, height, random);
                paint.setColor(p.color);
                paint.setAlpha(p.alpha);
                canvas.drawCircle(p.x, p.y, p.radius, paint);
            }
            invalidate();
        }

        public void stopParticles() {
            isRunning = false;
            particles.clear();
        }

        private static class Particle {
            float x, y, radius, speedX, speedY;
            int color, alpha;

            void update(int width, int height, Random r) {
                if (radius == 0 || x < 0 || x > width || y < 0 || y > height || alpha <= 0) {
                    x = r.nextInt(width);
                    y = r.nextInt(height);
                    radius = 3 + r.nextFloat() * 6;
                    speedX = -1.5f + r.nextFloat() * 3f;
                    speedY = -2.5f + r.nextFloat() * 1.5f; 
                    alpha = 50 + r.nextInt(150);

                    int colorType = r.nextInt(3);
                    if (colorType == 0) {
                        colorColor(Color.WHITE);
                    } else if (colorType == 1) {
                        colorColor(Color.parseColor("#E040FB"));
                    } else {
                        colorColor(Color.parseColor("#80DEEA"));
                    }
                } else {
                    x += speedX;
                    y += speedY;
                    alpha -= 1;
                }
            }

            private void colorColor(int c) {
                this.color = c;
            }
        }
    }
} // Tanda kurung kurawal penutup akhir dari file activity
