package com.nyx.tools;

import com.nyx.tools.SplashScreenActivity;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.GravityCompat;
import androidx.documentfile.*;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.AndroidSketchwareMaster.*;
import com.android.volley.*;
import com.google.android.gms.ads.MobileAds;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import com.kaopiz.kprogresshud.*;
import com.stx.xhb.androidx.*;
import com.stx.xhb.androidx.XBanner;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.*;
import java.util.zip.*;
import java.util.concurrent.TimeUnit;
import android.database.*;
import androidx.core.widget.NestedScrollView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.graphics.Insets;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.android.volley.VolleyError;

import org.json.JSONObject;
import android.provider.Settings;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;

import java.net.NetworkInterface;
import java.util.Collections;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.Process;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.nyx.tools.security.JsonManager;

import com.nyx.tools.MenuAdapter;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private DrawerLayout _drawer;
	private double num = 0;
	private boolean sliderv = false;
	private String r = "";
	private double exit = 0;
	private HashMap<String, Object> bannerList = new HashMap<>();
	private double n1 = 0;
	private double count1 = 0;
	private double number = 0;
	private double lenght = 0;
	private String save = "";
	private String value = "";
	private HashMap<String, Object> map = new HashMap<>();
	private HashMap<String, Object> maps = new HashMap<>();
	private HashMap<String, Object> cacheMap = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> lm = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	private ArrayList<String> list = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lp = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lmap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> cache = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> breh = new ArrayList<>();
	
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear1;
	private XBanner banner;
	private RecyclerView recyclerview1;
	private ImageView imageview1;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private ImageView imageview2;
	private LinearLayout _drawer_linear6;
	private LinearLayout _drawer_linear1;
	private LinearLayout _drawer_linear5;
	private ScrollView _drawer_vscroll1;
	private ImageView _drawer_imageview19;
	private ImageView _drawer_imageview3;
	private TextView _drawer_textview1;
	private ImageView _drawer_imageview4;
	private LinearLayout _drawer_linear14;
	private LinearLayout _drawer_linear7;
	private LinearLayout _drawer_linear8;
	private LinearLayout _drawer_linear9;
	private LinearLayout _drawer_linear10;
	private LinearLayout _drawer_linear11;
	private LinearLayout _drawer_linear12;
	private ImageView _drawer_imageview5;
	private TextView _drawer_textview2;
	private ImageView _drawer_imageview6;
	private ImageView _drawer_imageview7;
	private TextView _drawer_textview3;
	private ImageView _drawer_imageview8;
	private ImageView _drawer_imageview9;
	private TextView _drawer_textview4;
	private ImageView _drawer_imageview10;
	private ImageView _drawer_imageview11;
	private TextView _drawer_textview5;
	private ImageView _drawer_imageview12;
	private ImageView _drawer_imageview13;
	private TextView _drawer_textview6;
	private ImageView _drawer_imageview14;
	private ImageView _drawer_imageview15;
	private TextView _drawer_textview7;
	private ImageView _drawer_imageview16;
	
	private TimerTask timer;
	private Intent i = new Intent();
	private AlertDialog.Builder d;
	private SharedPreferences sp;
	private TimerTask t;
	private AlertDialog.Builder drawer;
	private Intent a = new Intent();
	private RequestNetwork v;
	private RequestNetwork.RequestListener _v_request_listener;
	private RequestNetwork req_banner;
	private RequestNetwork.RequestListener _req_banner_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = findViewById(R.id._drawer);
		ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(MainActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = findViewById(R.id._nav_view);
		
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		linear1 = findViewById(R.id.linear1);
		banner = findViewById(R.id.banner);
		recyclerview1 = findViewById(R.id.recyclerview1);
		imageview1 = findViewById(R.id.imageview1);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		imageview2 = findViewById(R.id.imageview2);
		_drawer_linear6 = _nav_view.findViewById(R.id.linear6);
		_drawer_linear1 = _nav_view.findViewById(R.id.linear1);
		_drawer_linear5 = _nav_view.findViewById(R.id.linear5);
		_drawer_vscroll1 = _nav_view.findViewById(R.id.vscroll1);
		_drawer_imageview19 = _nav_view.findViewById(R.id.imageview19);
		_drawer_imageview3 = _nav_view.findViewById(R.id.imageview3);
		_drawer_textview1 = _nav_view.findViewById(R.id.textview1);
		_drawer_imageview4 = _nav_view.findViewById(R.id.imageview4);
		_drawer_linear14 = _nav_view.findViewById(R.id.linear14);
		_drawer_linear7 = _nav_view.findViewById(R.id.linear7);
		_drawer_linear8 = _nav_view.findViewById(R.id.linear8);
		_drawer_linear9 = _nav_view.findViewById(R.id.linear9);
		_drawer_linear10 = _nav_view.findViewById(R.id.linear10);
		_drawer_linear11 = _nav_view.findViewById(R.id.linear11);
		_drawer_linear12 = _nav_view.findViewById(R.id.linear12);
		_drawer_imageview5 = _nav_view.findViewById(R.id.imageview5);
		_drawer_textview2 = _nav_view.findViewById(R.id.textview2);
		_drawer_imageview6 = _nav_view.findViewById(R.id.imageview6);
		_drawer_imageview7 = _nav_view.findViewById(R.id.imageview7);
		_drawer_textview3 = _nav_view.findViewById(R.id.textview3);
		_drawer_imageview8 = _nav_view.findViewById(R.id.imageview8);
		_drawer_imageview9 = _nav_view.findViewById(R.id.imageview9);
		_drawer_textview4 = _nav_view.findViewById(R.id.textview4);
		_drawer_imageview10 = _nav_view.findViewById(R.id.imageview10);
		_drawer_imageview11 = _nav_view.findViewById(R.id.imageview11);
		_drawer_textview5 = _nav_view.findViewById(R.id.textview5);
		_drawer_imageview12 = _nav_view.findViewById(R.id.imageview12);
		_drawer_imageview13 = _nav_view.findViewById(R.id.imageview13);
		_drawer_textview6 = _nav_view.findViewById(R.id.textview6);
		_drawer_imageview14 = _nav_view.findViewById(R.id.imageview14);
		_drawer_imageview15 = _nav_view.findViewById(R.id.imageview15);
		_drawer_textview7 = _nav_view.findViewById(R.id.textview7);
		_drawer_imageview16 = _nav_view.findViewById(R.id.imageview16);
		d = new AlertDialog.Builder(this);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		drawer = new AlertDialog.Builder(this);
		v = new RequestNetwork(this);
		req_banner = new RequestNetwork(this);
		
		_v_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				// ========================================================
				// 📡 ON RESPONSE V (SUDAH DIKOREKSI TOTAL)
				// ========================================================
				
				// Satukan inisialisasi SharedPreferences ke satu pintu untuk mencegah NullPointer
				SharedPreferences cache = getSharedPreferences("JSON_CACHE", MODE_PRIVATE);
				
				// ========================================================
				// 👑 HERO DETAIL
				// ========================================================
				if (_tag.equals("hero_detail")) {
					try {
						// Simpan ke xml cache yang sama 'JSON_CACHE'
						cache.edit().putString("cache_detail_hero", _response).apply();
						
						// PERBAIKAN: Memanggil fungsi helper dari MainActivity (Tanpa restore scroll)
						MainActivity.this._updateRecyclerView("JSON_CACHE", false);
						
					} catch (Exception e) {
						e.printStackTrace();
					}
					return;
				}
				
				// ========================================================
				// 📦 MENUZERO
				// ========================================================
				if (_tag.equals("menuzero")) {
					String oldJson = cache.getString("menuzero", "");
					try {
						// ==================================================
						// PARSE & VALIDASI MENU
						// ==================================================
						breh = new Gson().fromJson(
						_response,
						new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
						);
						
						if (breh == null || breh.size() == 0) {
							return;
						}
						
						// ==================================================
						// SIMPAN CACHE MENU JIKA ADA PERUBAHAN
						// ==================================================
						if (!_response.equals(oldJson)) {
							cache.edit().putString("menuzero", _response).apply();
						}
						
						// ==================================================
						// UPDATE UI & PEMULIHAN SCROLL
						// ==================================================
						// PERBAIKAN: Memanggil fungsi helper dari MainActivity (Jalankan restore scroll)
						MainActivity.this._updateRecyclerView("JSON_CACHE", true);
						
						save = new Gson().toJson(breh);
						
					} catch (Exception e) {
						e.printStackTrace();
					}
					return;
				}
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_req_banner_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				// 🔴 BUNGKUS DENGAN TRY-CATCH
				try {
					// Bersihkan spasi dan cek apakah data diawali tanda JSON seperti '[' atau '{'
					String dataBersih = _response.trim();
					
					if (dataBersih.startsWith("[") || dataBersih.startsWith("{")) {
						
						// Coba lakukan parse simulasi untuk memastikan JSON benar-benar valid secara format
						new Gson().fromJson(dataBersih, Object.class);
						
						SharedPreferences cache = getSharedPreferences("JSON_CACHE", MODE_PRIVATE);
						String oldJson = cache.getString("bannerzero", "");
						
						// ===== UPDATE CACHE JIKA BERUBAH =====
						if (!dataBersih.equals(oldJson)) {
							cache.edit().putString("bannerzero", dataBersih).apply();
						}
						
						// ===== RENDER SELALU DARI CACHE =====
						_renderBanner();
					}
				} catch (Exception e) {
					// 🔴 JIKA JSON BANNER RUSAK, APLIKASI TETAP AMAN DAN MENGGUNAKAN BANNER LAMA
					e.printStackTrace();
				}
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_drawer_linear5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				WebViewHelper.show(MainActivity.this,
				"https://updateterbaru7.blogspot.com");
			}
		});
		
		_drawer_linear7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_drawer.closeDrawer(GravityCompat.START);
				i.setAction(Intent.ACTION_VIEW);
				i.setData(Uri.parse("https://chat.whatsapp.com/LdFrdpAX4gP5xLjoGYzAsS"));
				startActivity(i);
			}
		});
		
		_drawer_linear8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_drawer.closeDrawer(GravityCompat.START);
				Intent shareIntent = new Intent(Intent.ACTION_SEND);
				shareIntent.setType("text/plain");
				shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Nyx Tools");
				shareIntent.putExtra(
				Intent.EXTRA_TEXT,
				"Download Nyx Tools:\nhttps://play.google.com/store/apps/details?id=com.nyx.tools"
				);
				
				startActivity(Intent.createChooser(shareIntent, "Bagikan via"));
				
			}
		});
		
		_drawer_linear9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setAction(Intent.ACTION_VIEW);
				i.setData(Uri.parse("https://play.google.com/store/apps/details?id=com.nyx.tools"));
				startActivity(i);
			}
		});
		
		_drawer_linear10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_drawer.closeDrawer(GravityCompat.START);
				Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://nyxtoolsprivacy.blogspot.com/p/nyx-tools-privacy-policy.html"));
				startActivity(browserIntent);
			}
		});
		
		_drawer_linear11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_drawer.closeDrawer(GravityCompat.START);
				Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
				emailIntent.setData(Uri.parse("mailto:toolsnyx@gmail.com"));
				emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject Email Anda");
				emailIntent.putExtra(Intent.EXTRA_TEXT, "Isi dari email ini.");
				startActivity(emailIntent);
				
			}
		});
		
		_drawer_linear12.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				// =============================================================
				// 🔹 DIALOG ADMIN — TANPA LINEAR12 (langsung tampil)
				// =============================================================
				AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
				builder.setTitle("Contact Admin");
				
				// Gunakan ScrollView biar aman di layar kecil
				ScrollView scroll = new ScrollView(MainActivity.this);
				scroll.setFillViewport(true);
				
				float density = getResources().getDisplayMetrics().density;
				
				// Layout utama dialog
				LinearLayout layout = new LinearLayout(MainActivity.this);
				layout.setOrientation(LinearLayout.VERTICAL);
				layout.setPadding((int)(25 * density), (int)(20 * density), (int)(25 * density), (int)(20 * density));
				layout.setGravity(Gravity.CENTER);
				
				LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				(int)(50 * density)
				);
				btnParams.setMargins(0, (int)(10 * density), 0, 0);
				
				Button btnAdmin1 = new Button(MainActivity.this);
				btnAdmin1.setText("Admin Ganteng");
				btnAdmin1.setTextColor(Color.WHITE);
				btnAdmin1.setAllCaps(false);
				btnAdmin1.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13); // 🟢 ukuran teks tombol
				btnAdmin1.setTypeface(null, Typeface.BOLD);
				btnAdmin1.setLayoutParams(btnParams);
				// --- Tombol Close ---
				Button btnClose = new Button(MainActivity.this);
				btnClose.setText("Close");
				btnClose.setTextColor(Color.WHITE);
				btnClose.setAllCaps(false);
				btnClose.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13); // 🟢 ukuran teks tombol
				btnClose.setTypeface(null, Typeface.BOLD);
				btnClose.setLayoutParams(btnParams);
				
				// Tambahkan tombol ke layout
				layout.addView(btnAdmin1);
				layout.addView(btnClose);
				scroll.addView(layout);
				builder.setView(scroll);
				
				// Buat dan tampilkan dialog
				final AlertDialog dialog = builder.create();
				dialog.setCancelable(false);
				dialog.setCanceledOnTouchOutside(false);
				dialog.show();
				
				// 🔹 Buat judul dialog jadi bold + ukuran 14 DIP
				int titleId = dialog.getContext().getResources().getIdentifier("alertTitle", "id", "android");
				TextView dialogTitle = dialog.findViewById(titleId);
				if (dialogTitle != null) {
					dialogTitle.setTypeface(null, Typeface.BOLD);
					dialogTitle.setTextColor(Color.WHITE);
					dialogTitle.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14); // 🟢 ukuran judul
				}
				
				// 🔹 Gaya background dialog
				GradientDrawable bg = new GradientDrawable();
				bg.setCornerRadius(20 * density);
				bg.setColor(Color.BLACK);
				bg.setStroke(4, Color.parseColor("#FFFFFF"));
				if (dialog.getWindow() != null) {
					dialog.getWindow().setBackgroundDrawable(bg);
					dialog.getWindow().getAttributes().windowAnimations = android.R.style.Animation_Dialog;
				}
				
				// 🔹 Efek sentuhan tombol
				View.OnTouchListener btnTouchAnim = new View.OnTouchListener() {
					@Override
					public boolean onTouch(View btn, MotionEvent event) {
						switch (event.getAction()) {
							case MotionEvent.ACTION_DOWN:
							btn.animate().scaleX(0.9f).scaleY(0.9f).setDuration(100).start();
							break;
							case MotionEvent.ACTION_UP:
							case MotionEvent.ACTION_CANCEL:
							btn.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
							break;
						}
						return false;
					}
				};
				
				// 🔹 Style tombol
				GradientDrawable btnStyleBrown = new GradientDrawable();
				btnStyleBrown.setCornerRadius(16 * density);
				btnStyleBrown.setColor(Color.parseColor("#4A148C"));
				btnStyleBrown.setStroke(3, Color.WHITE);
				
				GradientDrawable btnStyleRed = new GradientDrawable();
				btnStyleRed.setCornerRadius(16 * density);
				btnStyleRed.setColor(Color.parseColor("#D50000"));
				btnStyleRed.setStroke(3, Color.WHITE);
				
				// Tombol Admin 1
				btnAdmin1.setBackground(btnStyleBrown);
				btnAdmin1.setOnTouchListener(btnTouchAnim);
				btnAdmin1.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v1) {
						Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://Wa.me/+6283842778395"));
						startActivity(i);
					}
				});
				// Tombol Close (merah)
				btnClose.setBackground(btnStyleRed);
				btnClose.setOnTouchListener(btnTouchAnim);
				btnClose.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v3) {
						dialog.dismiss();
					}
				});
				
			}
		});
	}
	
	private void initializeLogic() {
		DialogUtil.applySecureEdgeToEdge(this);
		DialogUtil.registerExitDialog(this);
		// ========================================================
		// 🎨 BANNER — TETAP, JANGAN DIUBAH
		// ========================================================
		_renderBanner();
		
		String bannerUrl = JsonManager.getJsonUrl("bannerzero");
		
		req_banner.startRequestNetwork(
		RequestNetworkController.GET,
		bannerUrl,
		"bannerzero",
		_req_banner_request_listener
		);
		
		
		// ========================================================
		// 📦 LOAD CACHE MENUZERO + HERO DETAIL (ANTI-CRASH & OFFLINE-READY)
		// ========================================================
		try {
			// Inisialisasi SharedPreferences secara konsisten untuk mencegah NullPointer
			SharedPreferences cache = getSharedPreferences("JSON_CACHE", MODE_PRIVATE);
			
			String menuJsonCache = cache.getString("menuzero", "");
			// PERBAIKAN UTAMA: Mengubah 'sp.getString' menjadi 'cache.getString' agar tidak NullPointer
			String heroDetailJson = cache.getString("cache_detail_hero", "");
			
			// ====================================================
			// 🟢 TAMPILKAN CACHE TERLEBIH DAHULU (UJI OFFLINE TIM GOOGLE)
			// ====================================================
			if (menuJsonCache != null && !menuJsonCache.isEmpty()) {
				try {
					breh = new Gson().fromJson(
					menuJsonCache,
					new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
					);
					
					if (breh != null && breh.size() > 0) {
						recyclerview1.setLayoutManager(
						new androidx.recyclerview.widget.LinearLayoutManager(MainActivity.this)
						);
						
						// OPTIMASI: Set true agar rendering layout item jauh lebih efisien & hemat memori
						recyclerview1.setHasFixedSize(true);
						// PERBAIKAN: Matikan nested scroll agar tidak memicu memory leak di HP tim peninjau
						recyclerview1.setNestedScrollingEnabled(false);
						
						MenuAdapter menuAdapter = new MenuAdapter(
						MainActivity.this,
						breh,
						heroDetailJson
						);
						
						recyclerview1.setAlpha(0f);
						recyclerview1.setAdapter(menuAdapter);
						
						recyclerview1.animate()
						.alpha(1f)
						.setDuration(180)
						.start();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		// ========================================================
		// 🌐 REQUEST MENUZERO — SELALU DIJALANKAN (BACKGROUND)
		// ========================================================
		String menuUrl = JsonManager.getJsonUrl("menuzero");
		
		v.startRequestNetwork(
		RequestNetworkController.GET,
		menuUrl,
		"menuzero",
		_v_request_listener
		);
		
		
		// ========================================================
		// 👑 REQUEST HERO DETAIL — SELALU DIJALANKAN (BACKGROUND)
		// ========================================================
		String heroDetailUrl = "https://lioxmenthol.github.io/Detail-hero/detail_hero.json";
		
		v.startRequestNetwork(
		RequestNetworkController.GET,
		heroDetailUrl,
		"hero_detail",
		_v_request_listener
		);
		
		_checkUpdate();
		_drawer_textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/quick.ttf"), 3);
		_drawer_textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/quick.ttf"), 3);
		_drawer_textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/quick.ttf"), 3);
		_drawer_textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/quick.ttf"), 3);
		_drawer_textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/quick.ttf"), 3);
		_drawer_textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/quick.ttf"), 3);
		_drawer_textview7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/quick.ttf"), 3);
		_drawer_textview1.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
		_drawer_textview2.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
		_drawer_textview3.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
		_drawer_textview4.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
		_drawer_textview5.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
		_drawer_textview6.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
		_drawer_textview7.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14);
		_toolbar.setVisibility(View.GONE);
		// ---------------------
		// imageview1 (touch + buka drawer)
		// ---------------------
		imageview1.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
					v.animate().scaleX(0.7f).scaleY(0.7f).setDuration(100).start();
					break;
					case MotionEvent.ACTION_UP:
					case MotionEvent.ACTION_CANCEL:
					v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
					break;
				}
				return false;
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				_drawer.openDrawer(GravityCompat.START);
			}
		});
		
		imageview2.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
					v.animate().scaleX(0.7f).scaleY(0.7f).setDuration(100).start();
					break;
					case MotionEvent.ACTION_UP:
					case MotionEvent.ACTION_CANCEL:
					v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
					break;
				}
				return false;
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				
				ScrollView scroll = new ScrollView(MainActivity.this);
				scroll.setFillViewport(true); // 🔥 penting biar full & bisa scroll
				
				LinearLayout layout = new LinearLayout(MainActivity.this);
				layout.setOrientation(LinearLayout.VERTICAL);
				layout.setPadding(40, 30, 40, 30);
				scroll.addView(layout);
				
				final float density = getResources().getDisplayMetrics().density;
				
				LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.MATCH_PARENT,
				(int) (45 * density)
				);
				btnParams.setMargins(0, (int) (12 * density), 0, 0);
				
				// 🔹 Animasi tombol
				View.OnTouchListener btnTouchAnim = new View.OnTouchListener() {
					@Override
					public boolean onTouch(View btn, MotionEvent event) {
						switch(event.getAction()) {
							case MotionEvent.ACTION_DOWN:
							btn.animate().scaleX(0.7f).scaleY(0.7f).setDuration(100).start();
							break;
							case MotionEvent.ACTION_UP:
							case MotionEvent.ACTION_CANCEL:
							btn.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
							break;
						}
						return false;
					}
				};
				
				// 🔹 Drawable beda-beda (fix bug warna)
				GradientDrawable bg1 = new GradientDrawable();
				bg1.setCornerRadius(16 * density);
				bg1.setColor(Color.parseColor("#4A148C"));
				bg1.setStroke(3, Color.WHITE);
				
				GradientDrawable bg5 = new GradientDrawable();
				bg5.setCornerRadius(16 * density);
				bg5.setColor(Color.parseColor("#D50000"));
				bg5.setStroke(3, Color.WHITE);
				
				// 🔹 Button
				Button btnV1 = new Button(MainActivity.this);
				btnV1.setText("TUTORIAL NYX TOOLS");
				btnV1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
				btnV1.setTextColor(Color.WHITE);
				btnV1.setAllCaps(false);
				btnV1.setLayoutParams(btnParams);
				btnV1.setBackground(bg1);
				btnV1.setOnTouchListener(btnTouchAnim);
				
				Button btnClose = new Button(MainActivity.this);
				btnClose.setText("Close");
				btnClose.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
				btnClose.setTextColor(Color.WHITE);
				btnClose.setAllCaps(false);
				btnClose.setLayoutParams(btnParams);
				btnClose.setBackground(bg5);
				btnClose.setOnTouchListener(btnTouchAnim);
				
				layout.addView(btnV1);
				layout.addView(btnClose);
				
				AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
				builder.setTitle("NYX TOOLS");
				builder.setIcon(android.R.drawable.ic_dialog_info);
				builder.setMessage(
				"🇲🇨MAU JOIN GRUP ADMIN DI MENU AWAL ATAU DRAWER POJOK KIRI ATAS / KALIAN BISA SLIDE LAYAR KALIAN DARI UJUNG KIRI KE KANAN\n" +
				"TUTORIAL PEMASANGAN ADA DI TOMBOL BAWAH INI\n\n" +
				
				"🇬🇧NEED JOIN THE ADMIN GROUP IN FIRST MENU OR THE TOP LEFT CORNER DRAWER / YOU CAN SLIDE YOUR SCREEN FROM LEFT TO RIGHT\n" +
				"HOW TO USE CLICK THIS DOWN\n\n"
				);
				builder.setView(scroll);
				
				final AlertDialog dialogHelp = builder.create();
				dialogHelp.show();
				
				// 🔹 Paksa ukuran text message & title
				int titleId = dialogHelp.getContext().getResources().getIdentifier("alertTitle", "id", "android");
				TextView tvTitle = dialogHelp.findViewById(titleId);
				if (tvTitle != null) {
					tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
					tvTitle.setTextColor(Color.WHITE);
				}
				
				int messageId = dialogHelp.getContext().getResources().getIdentifier("message", "id", "android");
				TextView tvMessage = dialogHelp.findViewById(messageId);
				if (tvMessage != null) {
					tvMessage.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
					tvMessage.setTextColor(Color.WHITE);
				}
				
				// 🔹 Background dialog
				GradientDrawable bgDialog = new GradientDrawable();
				bgDialog.setCornerRadius(20 * density);
				bgDialog.setColor(Color.BLACK);
				bgDialog.setStroke(4, Color.parseColor("#FFFFFF"));
				if (dialogHelp.getWindow() != null) {
					dialogHelp.getWindow().setBackgroundDrawable(bgDialog);
				}
				
				// 🔹 Klik tombol
				btnV1.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						v.animate().scaleX(1f).scaleY(1f).setDuration(50).start();
						startActivity(new Intent(Intent.ACTION_VIEW,
						Uri.parse("https://youtube.com/playlist?list=PL3fU1kworLKPIT97AfWDdqXX6Ni68HgyH&si=7PMRbc0mJTnhcUKX")));
					}
				});
				
				btnClose.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						dialogHelp.dismiss();
					}
				});
			}
		});
	}
	
	
	@Override
	public void onResume() {
		super.onResume();
		Object runnableAmbilan = getWindow().getDecorView().getTag(R.id.layoutHeroStats);
		if (runnableAmbilan instanceof Runnable) {
			((Runnable) runnableAmbilan).run();
		}
		
		// =========================================================
		// 🔒 2. LOGIKA PEMBLOKIR DNS & VPN BAWAAN KAMU (TERJAGA AMAN)
		// =========================================================
		final SharedPreferences prefs = getSharedPreferences("app_prefs", MODE_PRIVATE);
		
		long now = System.currentTimeMillis();
		long lastShown = prefs.getLong("lastAlertTime", 0);
		
		// Cooldown 10 detik khusus untuk dialog pemblokir
		if (now - lastShown < 10_000) {
			return;
		}
		
		// Tunda lebih lama supaya iklan tidak terganggu
		new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
			@Override
			public void run() {
				
				if (isFinishing() || isDestroyed()) return;
				
				// Cek ringan & aman (urutan penting)
				boolean blocked = false;
				
				if (_isBlockedDNS()) {
					blocked = true;
				} else if (_isVPNEnabled()) {
					blocked = true;
				}
				
				if (blocked) {
					// Dialog muncul saat UI sudah stabil
					_showBlockDialog();
					
					prefs.edit()
					.putLong("lastAlertTime", System.currentTimeMillis())
					.apply();
				}
			}
		}, 3000);
		
	}
	
	@Override
	public void onBackPressed() {
		DialogUtil.showCustomExitDialog(this);
	}
	public void _checkUpdate() {
		String url = "https://gist.github.com/Lioxmenthol/9b52c39536a56d811347d26a04ac4c10/raw/nyxtools.json";
		
		RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
		
		StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
		new Response.Listener<String>() {
			@Override
			public void onResponse(String response) {
				try {
					JSONObject json = new JSONObject(response);
					
					int latestVersion = json.getInt("latest_version");
					String changelog = json.getString("changelog");
					String downloadUrl = json.getString("download");
					
					int currentVersion = getPackageManager()
					.getPackageInfo(getPackageName(), 0).versionCode;
					
					if (latestVersion > currentVersion) {
						_showUpdateDialog(changelog, downloadUrl);
					}
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		},
		new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				// bisa kosong atau tampilkan log
				error.printStackTrace();
			}
		}
		);
		
		queue.add(stringRequest);
	}
	
	
	public void _showUpdateDialog(final String _changelog, final String _downloadUrl) {
		// 1. BUAT LAYOUT KUSTOM SECARA LANGSUNG DARI JAVA (Tanpa File XML)
		android.widget.LinearLayout mainContainer = new android.widget.LinearLayout(MainActivity.this);
		mainContainer.setOrientation(android.widget.LinearLayout.VERTICAL);
		mainContainer.setPadding(60, 45, 60, 45);
		
		// A. Buat Komponen Judul Dialog
		android.widget.TextView tvTitle = new android.widget.TextView(MainActivity.this);
		tvTitle.setText("NYX TOOLS");
		tvTitle.setTextColor(android.graphics.Color.WHITE);
		tvTitle.setTextSize(18);
		tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
		tvTitle.setPadding(0, 0, 0, 30);
		mainContainer.addView(tvTitle);
		
		// B. Buat Komponen Pesan / Changelog
		android.widget.TextView tvMessage = new android.widget.TextView(MainActivity.this);
		tvMessage.setText("Versi terbaru sudah tersedia / New Version Already.\n\nChangelog:\n" + _changelog);
		tvMessage.setTextColor(android.graphics.Color.WHITE);
		tvMessage.setTextSize(14);
		tvMessage.setPadding(0, 0, 0, 45);
		mainContainer.addView(tvMessage);
		
		// C. Buat Container Khusus untuk Tombol agar Pasti Berada di Tengah
		android.widget.LinearLayout buttonContainer = new android.widget.LinearLayout(MainActivity.this);
		buttonContainer.setOrientation(android.widget.LinearLayout.HORIZONTAL);
		buttonContainer.setGravity(android.view.Gravity.CENTER); // Mengunci posisi tepat di tengah-tengah
		
		// D. Buat Tombol UPDATE Tunggal Kustom (Kuning, Teks Hitam)
		android.widget.Button btnUpdate = new android.widget.Button(MainActivity.this);
		btnUpdate.setText("UPDATE");
		btnUpdate.setTextColor(android.graphics.Color.parseColor("#FFFFFF")); // Teks Hitam
		btnUpdate.setAllCaps(true);
		btnUpdate.setTextSize(14);
		btnUpdate.setTypeface(null, android.graphics.Typeface.BOLD);
		btnUpdate.setPadding(60, 25, 60, 25); // Membuat tombol terlihat berisi dan gagah
		
		// Desain Background Kuning dengan Efek Sentuh Ripple Animasi
		android.graphics.drawable.GradientDrawable bgUpdate = new android.graphics.drawable.GradientDrawable();
		bgUpdate.setColor(android.graphics.Color.parseColor("#4A148C")); // Kuning asli
		bgUpdate.setCornerRadius(16); // Efek Melengkung (Corner)
		btnUpdate.setBackground(new android.graphics.drawable.RippleDrawable(
		android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#20000000")), 
		bgUpdate, 
		null
		));
		
		// Atur ukuran lebar tombol agar pas dengan teksnya (Wrap Content)
		android.widget.LinearLayout.LayoutParams btnParams = new android.widget.LinearLayout.LayoutParams(
		android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
		android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
		);
		btnUpdate.setLayoutParams(btnParams);
		
		// Masukkan tombol ke dalam container tombol, lalu masukkan container ke container utama
		buttonContainer.addView(btnUpdate);
		mainContainer.addView(buttonContainer);
		
		// =======================================================
		// 2. BANGUN DIALOG MENGGUNAKAN CONTAINER BUATAN KITA
		// =======================================================
		android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(MainActivity.this);
		builder.setView(mainContainer); // Menempelkan container kustom kita ke dalam Dialog
		builder.setCancelable(false); // Kunci agar tidak bisa ditutup klik luar
		
		final android.app.AlertDialog dialog = builder.create();
		dialog.show();
		
		// Pasang Latar Belakang Hitam, Stroke Kuning, dan Corner pada Bingkai Luar Dialog
		android.graphics.drawable.GradientDrawable dialogBg = new android.graphics.drawable.GradientDrawable();
		dialogBg.setColor(android.graphics.Color.BLACK);
		dialogBg.setStroke(4, android.graphics.Color.parseColor("#4A148C")); // Stroke Kuning
		dialogBg.setCornerRadius(24); // Lengkungan Luar
		if (dialog.getWindow() != null) {
			dialog.getWindow().setBackgroundDrawable(dialogBg);
		}
		
		// =======================================================
		// 3. LOGIKA KLIK & ANIMASI FISIK TENGGELAM TOMBOL
		// =======================================================
		btnUpdate.setOnClickListener(new android.view.View.OnClickListener() {
			@Override
			public void onClick(android.view.View v) {
				// Ambil URL utuh dari Gist Anda
				String urlDariGist = _downloadUrl; 
				
				try {
					android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_VIEW);
					
					// OPTIONAL: Jika URL dari Gist adalah tautan web Play Store (https://play.google...),
					// kita bisa paksa HP untuk langsung membukanya di aplikasi Google Play Store (bukan browser).
					if (urlDariGist.contains("://google.com")) {
						String appId = urlDariGist.substring(urlDariGist.indexOf("?id=") + 4);
						intent.setData(android.net.Uri.parse("market://details?id=" + appId));
					} else {
						intent.setData(android.net.Uri.parse(urlDariGist));
					}
					
					intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(intent);
					
				} catch (android.content.ActivityNotFoundException e) {
					// JIKA HP user tidak punya aplikasi Play Store (contoh: Huawei/Emulator), 
					// kode ini bertindak sebagai BACKUP agar otomatis dibuka lewat Browser (Chrome/Opera) dan TIDAK CRASH.
					android.content.Intent browserIntent = new android.content.Intent(android.content.Intent.ACTION_VIEW);
					browserIntent.setData(android.net.Uri.parse(urlDariGist));
					browserIntent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(browserIntent);
				}
			}
		});
		
		
		btnUpdate.setOnTouchListener(new android.view.View.OnTouchListener() {
			@Override
			public boolean onTouch(android.view.View v, android.view.MotionEvent event) {
				if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
					v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(100).start(); // Mengecil (Tenggelam)
				} else if (event.getAction() == android.view.MotionEvent.ACTION_UP || event.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
					v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(100).start(); // Normal Kembali
				}
				return false;
			}
		});
		
	}
	
	
	public void _showBlockDialog() {
		if (isFinishing() || isDestroyed()) return;
		
		androidx.appcompat.app.AlertDialog.Builder builder =
		new androidx.appcompat.app.AlertDialog.Builder(this);
		
		builder.setTitle("Koneksi Tidak Stabil • Unstable Connection");
		
		builder.setMessage(
		"Beberapa pengaturan jaringan atau DNS dapat memengaruhi " +
		"kestabilan koneksi aplikasi.\n\n" +
		"Jika Anda mengalami kendala, silakan nonaktifkan sementara " +
		"pengaturan tersebut lalu coba kembali.\n\n" +
		"Some network or DNS configurations may affect the app’s " +
		"connection stability.\n\n" +
		"If you experience issues, please temporarily disable such " +
		"settings and try again."
		);
		
		// ✅ Biarkan user bisa dismiss
		builder.setCancelable(true);
		
		// 🔁 COBA LAGI / RETRY
		builder.setPositiveButton("Coba Lagi / Retry",
		new android.content.DialogInterface.OnClickListener() {
			@Override
			public void onClick(android.content.DialogInterface dialog, int which) {
				
				dialog.dismiss();
				
				// Cek ulang DNS secara ringan
				if (!_isBlockedDNS()) {
					// lanjutkan aplikasi
					// contoh: loadData(); atau refresh halaman
				}
			}
		});
		
		// ⬅️ KEMBALI / BACK (lebih aman daripada force close)
		builder.setNegativeButton("Kembali / Back",
		new android.content.DialogInterface.OnClickListener() {
			@Override
			public void onClick(android.content.DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		
		builder.show();
		
	}
	
	
	public boolean _isVPNEnabled() {
		try {
			// ================================
			// 1) VPN RESMI (PALING AMAN)
			// ================================
			ConnectivityManager cm =
			(ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
			
			if (cm != null) {
				Network network = cm.getActiveNetwork();
				NetworkCapabilities caps = cm.getNetworkCapabilities(network);
				
				if (caps != null &&
				caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
					return true;
				}
			}
			
			// ================================
			// 2) INTERFACE CHECK (BACKUP)
			// ================================
			for (NetworkInterface ni :
			java.util.Collections.list(NetworkInterface.getNetworkInterfaces())) {
				
				if (!ni.isUp() || ni.isLoopback()) continue;
				
				String name = ni.getName().toLowerCase(); // pakai getName(), lebih aman
				
				if (name.contains("tun")
				|| name.contains("wg")
				|| name.contains("ppp")) {
					
					return true;
				}
			}
			
			return false;
			
		} catch (Exception e) {
			return false;
		}
		
	}
	
	
	public boolean _isBlockedDNS() {
		try {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
				String mode = Settings.Global.getString(
				getContentResolver(),
				"private_dns_mode"
				);
				
				String host = Settings.Global.getString(
				getContentResolver(),
				"private_dns_specifier"
				);
				
				if ("hostname".equals(mode) && host != null) {
					host = host.toLowerCase();
					return host.contains("adguard")
					|| host.contains("nextdns")
					|| host.contains("blokada");
				}
			}
		} catch (Throwable ignored) {}
		return false;
	}
	
	
	public boolean _checkAdBlock() {
		if (_isVPNEnabled() || _isBlockedDNS()) {
			return true; // hanya kembalikan nilai
		}
		return false;
	}
	
	
	public void _AnehGamingOfficial(final ArrayList<HashMap<String, Object>> _listmap, final String _aneh) {
		Comparator list_sorter = new Comparator<HashMap<String, Object>>(){
			@Override
			public int compare(HashMap<String, Object> map2, HashMap<String, Object> map1){
				
				try {
					Double num1 = Double.parseDouble(map1.get(_aneh).toString());
					Double num2 = Double.parseDouble(map2.get(_aneh).toString());
					return Double.compare(num2, num1);
				} catch (NumberFormatException e){
					return map2.get(_aneh).toString().compareTo(map1.get(_aneh).toString());
				}
				
			}
		};
		
		Collections.sort(_listmap, list_sorter);
	}
	
	
	public void _renderBanner() {
		SharedPreferences cache = getSharedPreferences("JSON_CACHE", MODE_PRIVATE);
		String bannerJson = cache.getString("bannerzero", null);
		
		if (bannerJson == null || bannerJson.trim().equals("")) {
			return;
		}
		
		// 🔴 BUNGKUS PROSES DENGAN TRY-CATCH
		try {
			ArrayList<HashMap<String, Object>> bannerItems =
			new Gson().fromJson(
			bannerJson,
			new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
			);
			
			if (bannerItems == null || bannerItems.size() == 0) {
				return;
			}
			
			final ArrayList<HashMap<String, Object>> finalItems = bannerItems;
			final ArrayList<String> images = new ArrayList<>();
			
			for (HashMap<String, Object> item : finalItems) {
				if (item != null && item.containsKey("img") && item.get("img") != null) {
					images.add(item.get("img").toString());
				}
			}
			
			// Jika setelah di-filter ternyata tidak ada link gambar sama sekali, hentikan proses
			if (images.isEmpty()) return;
			
			banner.setData(R.layout.xbanner_item, images, null);
			
			banner.loadImage(new XBanner.XBannerAdapter() {
				@Override
				public void loadBanner(XBanner banner, Object model, View view, int position) {
					// 🔴 Amankan posisi index agar tidak IndexOutOfBoundsException jika list tiba-colapse
					if (position < 0 || position >= images.size()) return;
					
					final int pos = position;
					
					ImageView img = view.findViewById(R.id.tx);
					
					// Pastikan context view masih aktif sebelum Glide memuat gambar
					if (view.getContext() != null && img != null) {
						Glide.with(view.getContext())
						.load(images.get(pos))
						.into(img);
					}
				}
			});
			
		} catch (Exception e) {
			// 🔴 JIKA CACHE BANNER LOKAL RUSAK, APLIKASI TIDAK AKAN CRASH DI ONCREATE
			e.printStackTrace();
			
			// Hapus cache yang rusak agar pada peluncuran berikutnya aplikasi langsung bersih
			cache.edit().remove("bannerzero").apply();
		}
		
	}
	
	
	public void _Anehgaminginejvtor(final ImageView _img, final String _file, final String _url) {
		Glide.with(getContext(this)).load(_url).thumbnail(Glide.with(getContext(this)).load(getContext(this).getResources().getIdentifier(_file, "drawable", getContext(this).getPackageName()))).fitCenter().into(_img);
	}
	public Context getContext(Context c) {
		return c;
	}
	public Context getContext(Fragment f) {
		return f.getActivity();
	}
	public Context getContext(DialogFragment df) {
		return df.getActivity();
	}
	{
	}
	
	
	public void _updateRecyclerView(final String _cacheName, final boolean _shouldRestoreScroll) {
		// ===== SOLUSI SKETCHWARE: DEFINISIKAN PARAMETER SECARA MANUAL =====
		String cacheName = "JSON_CACHE";
		boolean shouldRestoreScroll = true; // Default bawaan More Block
		
		// Mengambil cache lokal secara aman berdasarkan parameter nama cache
		SharedPreferences cache = getSharedPreferences(cacheName, MODE_PRIVATE);
		
		String menuJson = cache.getString("menuzero", "");
		String heroDetailJson = cache.getString("cache_detail_hero", "");
		
		// Jika data menu utama belum siap dari internet/cache, batalkan rendering
		if (menuJson.isEmpty()) {
			return;
		}
		
		try {
			breh = new Gson().fromJson(
			menuJson,
			new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
			);
			
			if (breh != null && breh.size() > 0) {
				
				// Evaluasi status adapter saat ini untuk menghemat memori
				if (recyclerview1.getAdapter() == null) {
					// Pasang pertama kali (Fresh setup)
					MenuAdapter menuAdapter = new MenuAdapter(MainActivity.this, breh, heroDetailJson);
					recyclerview1.setLayoutManager(new androidx.recyclerview.widget.LinearLayoutManager(MainActivity.this));
					
					// Set performa optimal RecyclerView
					recyclerview1.setHasFixedSize(true);
					recyclerview1.setNestedScrollingEnabled(false);
					
					recyclerview1.setAlpha(0f);
					recyclerview1.setAdapter(menuAdapter);
					recyclerview1.animate().alpha(1f).setDuration(180).start();
				} else {
					// SINKRONISASI AKTIF: Jika data susulan datang, langsung timpa datanya saja.
					MenuAdapter menuAdapter = new MenuAdapter(MainActivity.this, breh, heroDetailJson);
					recyclerview1.setAdapter(menuAdapter);
				}
				
				// Kembalikan posisi scroll pengguna secara akurat
				if (shouldRestoreScroll) {
					SharedPreferences scrollSp = getSharedPreferences("SCROLL", MODE_PRIVATE);
					int pos = scrollSp.getInt("grid_pos_hero", 0);
					
					if (pos >= 0 && pos < breh.size()) {
						recyclerview1.postDelayed(new Runnable() {
							@Override
							public void run() {
								recyclerview1.scrollToPosition(pos + 1);
							}
						}, 100);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.menuzero, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final TextView textview2 = _view.findViewById(R.id.textview2);
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}