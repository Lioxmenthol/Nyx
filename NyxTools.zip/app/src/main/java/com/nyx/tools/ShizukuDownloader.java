package com.nyx.tools;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;

import com.AndroidSketchwareMaster.ShizukuMaster;
import com.kaopiz.kprogresshud.KProgressHUD;

import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;

public class ShizukuDownloader {

    private Activity activity;
    private ShizukuMaster shizuku;

    private static boolean isDownloading = false;

    private Handler handler =
            new Handler(Looper.getMainLooper());

    private PowerManager.WakeLock wakeLock;

    private KProgressHUD hud;

    private ProgressBar progressBar;

    private TextView txtTitle;
    private TextView txtPercent;
    private TextView txtSize;
    private TextView txtSpeed;
    private TextView txtEta;

    private LayoutInflater inflater;

    public ShizukuDownloader(
            Activity activity,
            ShizukuMaster shizuku
    ) {

        this.activity = activity;
        this.shizuku = shizuku;

        inflater = activity.getLayoutInflater();
    }
    
    private String formatSize(long bytes) {

    if (bytes <= 0)
        return "0 B";

    String[] units = {
            "B",
            "KB",
            "MB",
            "GB"
    };

    int digit = 0;

    double size = bytes;

    while (size >= 1024 && digit < units.length - 1) {

        size /= 1024;
        digit++;
    }

    return String.format(
            "%.2f %s",
            size,
            units[digit]
    );
}

private String formatSpeed(long bytesPerSec) {

    return formatSize(bytesPerSec) + "/s";
}

private String formatTime(long second) {

    long m = second / 60;

    long s = second % 60;

    return String.format(
            "%02d:%02d",
            m,
            s
    );
}

private void showHUD() {

    View v =
            inflater.inflate(
                    R.layout.ext,
                    null
            );

    LinearLayout linear =
            v.findViewById(
                    R.id.linear2
            );

    progressBar =
            v.findViewById(
                    R.id.progressbar1
            );

    txtTitle =
            v.findViewById(
                    R.id.txtTitle
            );

    txtPercent =
            v.findViewById(
                    R.id.textviewer
            );

    txtSize =
            v.findViewById(
                    R.id.txtSize
            );

    txtSpeed =
            v.findViewById(
                    R.id.txtSpeed
            );

    txtEta =
            v.findViewById(
                    R.id.txtEta
            );

    GradientDrawable bg =
            new GradientDrawable();

    bg.setColor(0xFF000000);

    bg.setCornerRadius(30);

    bg.setStroke(
            4,
            0xFFFFFFFF
    );

    linear.setBackground(bg);

    progressBar.setMax(100);

    progressBar.setProgress(0);
    
        // 1. MEWARNAI PROGRESS YANG BERJALAN MENJADI UNGU TUA
 if (progressBar.getProgressDrawable() instanceof android.graphics.drawable.LayerDrawable) {
        android.graphics.drawable.LayerDrawable layerDrawable = (android.graphics.drawable.LayerDrawable) progressBar.getProgressDrawable();
        android.graphics.drawable.Drawable progressDrawable = layerDrawable.findDrawableByLayerId(android.R.id.progress);
        if (progressDrawable != null) {
            progressDrawable.setColorFilter(0xFF00E5FF, android.graphics.PorterDuff.Mode.SRC_IN);
        }
        
        // 2. TAMBAHKAN KODE STROKE PUTIH INI DI SINI
        android.graphics.drawable.Drawable backgroundDrawable = layerDrawable.findDrawableByLayerId(android.R.id.background);
        if (backgroundDrawable instanceof android.graphics.drawable.GradientDrawable) {
            ((android.graphics.drawable.GradientDrawable) backgroundDrawable).setStroke(2, 0xFFFFFFFF);
        } else {
            android.graphics.drawable.GradientDrawable customBg = new android.graphics.drawable.GradientDrawable();
            customBg.setColor(0x33FFFFFF); 
            customBg.setStroke(2, 0xFFFFFFFF); 
            customBg.setCornerRadius(10); 
            layerDrawable.setDrawableByLayerId(android.R.id.background, customBg);
        }
    }

    txtTitle.setText("Preparing...");

    txtPercent.setText("0%");

    txtSize.setText("0 B / 0 B");

    txtSpeed.setText("0 KB/s");

    txtEta.setText("Remaining --:--");

    hud =
            KProgressHUD.create(activity)
                    .setStyle(
                            KProgressHUD.Style.SPIN_INDETERMINATE
                    )
                    .setCustomView(v)
                    .setCancellable(false);
                    
                    hud.setDimAmount(0.6f); // Menghasilkan bayangan hitam transparan 50%

    hud.show();
    
    try {
        android.view.ViewParent vp = v.getParent();
        while (vp instanceof android.view.View) {
            android.view.View parentView = (android.view.View) vp;
            // Bersihkan semua background warna bawaan library (termasuk pink)
            parentView.setBackgroundColor(android.graphics.Color.TRANSPARENT);
            
            // Hilangkan juga padding bawaan library agar layout hitam Anda tidak mengecil
            parentView.setPadding(0, 0, 0, 0);
            
            vp = parentView.getParent();
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}

private void dismissHUD() {
    
       if (hud != null &&
            hud.isShowing()) {

        hud.dismiss();
    }
}

    private void updateProgress(
        final int percent,
        final long current,
        final long total,
        final long speed,
        final long eta
) {

    handler.post(new Runnable() {

        @Override
        public void run() {

            progressBar.setProgress(percent);

            txtPercent.setText(percent + "%");

            txtSize.setText(
                    formatSize(current)
                            + " / "
                            + formatSize(total)
            );

            txtSpeed.setText(
                    formatSpeed(speed)
            );

            txtEta.setText(
                    "Remaining "
                            + formatTime(eta)
            );

        }

    });

}

private void updateTitle(final String title) {

    handler.post(new Runnable() {

        @Override
        public void run() {

            txtTitle.setText(title);

        }

    });

}

private void showToast(final String msg) {

    handler.post(new Runnable() {

        @Override
        public void run() {

            android.widget.Toast.makeText(
                    activity,
                    msg,
                    android.widget.Toast.LENGTH_LONG
            ).show();

        }

    });

}

private File getDownloadFolder() {

    File folder =
            new File(
                    activity.getExternalFilesDir(null),
                    "downloads"
            );

    if (!folder.exists()) {

        folder.mkdirs();

    }

    return folder;

}

private void acquireWakeLock() {

    PowerManager pm =
            (PowerManager)
                    activity.getSystemService(
                            Activity.POWER_SERVICE
                    );

    wakeLock =
            pm.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "ZERO:SHIZUKU_DOWNLOAD"
            );

    wakeLock.acquire(
            10 * 60 * 1000L
    );

}

private void releaseWakeLock() {

    if (wakeLock != null &&
            wakeLock.isHeld()) {

        wakeLock.release();

    }

}

private boolean isValidZip(File file) {

    return file.exists()
            &&
            file.length() > 0;

}

public void startDownload(
        final String url,
        final String fileName
) {

    if (isDownloading) {

        showToast("Masih ada download yang berjalan...");

        return;
    }

    isDownloading = true;

    acquireWakeLock();

    showHUD();
    
    

    new Thread(new Runnable() {

        @Override
        public void run() {

            try {

                File folder =
                        getDownloadFolder();

                File zipFile =
                        new File(
                                folder,
                                fileName
                        );

                if (zipFile.exists()) {

                    zipFile.delete();

                }

                updateTitle(
                        "Connecting..."
                );

                URL u =
                        new URL(url);

                HttpURLConnection conn =
                        (HttpURLConnection)
                                u.openConnection();

                conn.setConnectTimeout(15000);

                conn.setReadTimeout(15000);

                conn.connect();

                if (conn.getResponseCode()
                        != HttpURLConnection.HTTP_OK) {

                    throw new Exception(
                            "HTTP "
                                    + conn.getResponseCode()
                    );
                }

                final long totalSize =
                        conn.getContentLengthLong();

                downloadFile(
                        conn,
                        zipFile,
                        totalSize
                );

            } catch (Exception e) {

                releaseWakeLock();

                dismissHUD();

                isDownloading = false;

                showToast(
                        e.toString()
                );

            }

        }

    }).start();

}

private void downloadFile(
        HttpURLConnection conn,
        File zipFile,
        long totalSize
) throws Exception {

    updateTitle("Downloading...");

    java.io.InputStream input =
            new java.io.BufferedInputStream(
                    conn.getInputStream()
            );

    java.io.FileOutputStream output =
            new java.io.FileOutputStream(
                    zipFile
            );

    byte[] buffer = new byte[8192];

    int len;

    long downloaded = 0;

    long lastTime =
            System.currentTimeMillis();

    long lastBytes = 0;

    while ((len = input.read(buffer)) != -1) {

        output.write(
                buffer,
                0,
                len
        );

        downloaded += len;

        long now =
                System.currentTimeMillis();

        if (now - lastTime >= 1000) {

            long speed =
                    downloaded - lastBytes;

            long eta = 0;

            if (speed > 0) {

                eta =
                        (totalSize - downloaded)
                                / speed;

            }

            int percent = 0;

            if (totalSize > 0) {

                percent =
                        (int) (
                                downloaded
                                        * 100L
                                        / totalSize
                        );

            }

            updateProgress(
                    percent,
                    downloaded,
                    totalSize,
                    speed,
                    eta
            );

            lastBytes = downloaded;

            lastTime = now;

        }

    }

    output.flush();

    output.close();

    input.close();

    conn.disconnect();

    updateProgress(
            100,
            totalSize,
            totalSize,
            0,
            0
    );

    updateTitle("Extracting...");

new ShizukuHandler(
        activity,
        shizuku
).extract(
        zipFile.getAbsolutePath(),
        null,
        hud
);

releaseWakeLock();

isDownloading = false;

}
}