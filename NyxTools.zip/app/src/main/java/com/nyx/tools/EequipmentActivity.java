package com.nyx.tools;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.AndroidSketchwareMaster.*;
import com.android.volley.*;
import com.google.android.gms.ads.MobileAds;
import com.google.firebase.FirebaseApp;
import com.kaopiz.kprogresshud.*;
import com.stx.xhb.androidx.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import android.app.Dialog;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.util.TypedValue;
import android.graphics.Typeface;
import android.text.Html;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import java.net.NetworkInterface;
import com.bumptech.glide.Glide;
// ⚠️ Ganti com.zero.tools.skin di bawah ini dengan package name aslimu jika berbeda!
import com.nyx.tools.security.JsonManager;


public class EequipmentActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private LinearLayout linear2;
	private LinearLayout linear3;
	private GridView gridview1;
	private ImageView imageview1;
	private TextView textview2;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private ImageView imageview3;
	
	private SharedPreferences sp;
	private Intent i = new Intent();
	private AlertDialog.Builder d;
	private SharedPreferences aneh;
	private SharedPreferences down;
	private TimerTask tomer;
	private RequestNetwork baby;
	private RequestNetwork.RequestListener _baby_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.eequipment);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		gridview1 = findViewById(R.id.gridview1);
		imageview1 = findViewById(R.id.imageview1);
		textview2 = findViewById(R.id.textview2);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		imageview3 = findViewById(R.id.imageview3);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		d = new AlertDialog.Builder(this);
		aneh = getSharedPreferences("aneh", Activity.MODE_PRIVATE);
		down = getSharedPreferences("down", Activity.MODE_PRIVATE);
		baby = new RequestNetwork(this);
		
		_baby_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				// 1. Ambil SharedPreferences untuk perbandingan cache
				SharedPreferences cache = getSharedPreferences("JSON_CACHE", MODE_PRIVATE);
				String oldJson = cache.getString("equipment", "");
				
				// 🔴 BUNGKUS SELURUH PROSES DENGAN TRY-CATCH (ANTI-CRASH)
				try {
					// ===== 1. PARSE JSON TERLEBIH DAHULU (UJI VALIDASI SINKRONISASI DATA GITHUB) =====
					// Tipe token disesuaikan murni menjadi ArrayList<HashMap>
					_data = new com.google.gson.Gson().fromJson(
					_response,
					new com.google.gson.reflect.TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
					);
					
					if (_data == null || _data.size() == 0) return;
					
					// ===== 2. SIMPAN CACHE HANYA JIKA DATA VALID & ADA PERUBAHAN DI GITHUB =====
					if (!_response.equals(oldJson)) {
						cache.edit().putString("equipment", _response).apply();
					}
					
					// ===== 3. TAMPILKAN LANGSUNG KE GRIDVIEW (TANPA FILTER HERO) =====
					gridview1.setAdapter(new Gridview1Adapter(_data));
					gridview1.setAlpha(1f);
					
					// Segarkan tampilan adapter agar sinkron secara instan
					((BaseAdapter)gridview1.getAdapter()).notifyDataSetChanged();
					
				} catch (Exception e) {
					// 🔴 JIKA JSON INTERNET RUSAK ATAU ERROR HTML, TETAP AMAN DAN TIDAK CRASH
					e.printStackTrace();
				}
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		DialogUtil.applySecureEdgeToEdge(this);
		
		textview2.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
		textview2.setText(sp.getString("her", ""));
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/quick.ttf"), 3);
		// =========================================================
		// 🟢 INISIALISASI DATA UTAMA (AMAN TANPA TUTUP PAKSA METHOD)
		// =========================================================
		_data = new java.util.ArrayList<java.util.HashMap<String, Object>>();
		
		// ===== AMBIL CACHE EQUIPMENT =====
		SharedPreferences cache = getSharedPreferences("JSON_CACHE", MODE_PRIVATE);
		String jsonCache = cache.getString("equipment", null);
		
		// ===== JIKA ADA CACHE, TAMPILKAN SECEPAT KILAT =====
		if (jsonCache != null) {
			try {
				ArrayList<HashMap<String, Object>> cachedList = new com.google.gson.Gson().fromJson(
				jsonCache,
				new com.google.gson.reflect.TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
				);
				
				if (cachedList != null && cachedList.size() > 0) {
					_data.addAll(cachedList);
					
					gridview1.setAlpha(0f);
					gridview1.setAdapter(new Gridview1Adapter(_data));
					gridview1.animate().alpha(1f).setDuration(180).start();
				}
			} catch (Exception e) {
				e.printStackTrace();
				cache.edit().remove("equipment").apply();
			}
		}
		
		// ===== REQUEST NETWORK ONLINE (DENGAN CACHE BUSTING ANTI-LAG) =====
		String cacheBusterEquipment = "?v=" + System.currentTimeMillis();
		String eqUrl = JsonManager.getJsonUrl("equipment") + cacheBusterEquipment;
		
		baby.startRequestNetwork(
		RequestNetworkController.GET,
		eqUrl,
		"equipment",                 
		_baby_request_listener
		);
		
		imageview1.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
					v.animate().scaleX(0.7f).scaleY(0.7f).setDuration(100).start();
					break;
					case MotionEvent.ACTION_UP:
					case MotionEvent.ACTION_CANCEL:
					v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
					break;
				}
				return false;
			}
		});
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish(); // 🔥 INI KUNCINYA
			}
		});
		
		// imageview3 (touch + custom drawer-style dialog 1 tombol)
		// ---------------------
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				
				// Animasi tekan
				v.animate().scaleX(0.8f).scaleY(0.8f).setDuration(100)
				.withEndAction(new Runnable() {
					@Override
					public void run() {
						
						v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
						
						final float density = getResources().getDisplayMetrics().density;
						
						// 🔹 Layout utama
						LinearLayout layout = new LinearLayout(EequipmentActivity.this);
						layout.setOrientation(LinearLayout.VERTICAL);
						layout.setPadding(40, 40, 40, 30);
						
						// 🔹 ScrollView
						ScrollView scrollView = new ScrollView(EequipmentActivity.this);
						
						// 🔹 Text isi
						TextView message = new TextView(EequipmentActivity.this);
						message.setText(
						"⚠️ PEMBERITAHUAN & SANGGAHAN (DISCLAIMER):\n" +
						"Aplikasi ini adalah panduan independen yang dibuat oleh penggemar (Unofficial Fan-made App) dan TIDAK berafiliasi dengan pengembang resmi game terkait. Seluruh nama equipment, atribut, status, gambar, dan efek pasif yang disebutkan dalam panduan ini adalah hak cipta dan milik sepenuhnya dari pemilik sah masing-masing merek dagang.\n\n" +
						"Informasi di dalam aplikasi ini disediakan hanya sebagai referensi komunitas. Data dapat berubah sewaktu-waktu mengikuti pembaruan atau update patch versi game asli. Silakan periksa secara berkala agar racikan build kamu tetap up-to-date dengan meta saat ini!\n" +
						"----------------------------------------\n" +
						"⚠️ NOTICE & LEGAL DISCLAIMER:\n" +
						"This application is an independent fan-made guide (Unofficial App) and is NOT affiliated with or endorsed by the official game developer. All equipment names, attributes, stats, images, and passive effects mentioned herein are the registered trademarks and copyrights of their respective owners.\n\n" +
						"The information in this app is provided for community reference purposes only. Data is subject to change at any time following the official game patch updates. Please check back periodically to keep your build up-to-date with the current meta!"
						);
						
						
						message.setTextSize(14);
						message.setTextColor(Color.WHITE);
						message.setTypeface(Typeface.DEFAULT_BOLD);
						
						scrollView.addView(message);
						layout.addView(scrollView);
						
						// 🔹 BUTTON OK (CUSTOM FIX)
						Button okButton = new Button(EequipmentActivity.this);
						okButton.setText("OK");
						okButton.setTextSize(14);
						okButton.setTextColor(Color.WHITE);
						okButton.setTypeface(Typeface.DEFAULT_BOLD);
						okButton.setAllCaps(false);
						
						LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
						LinearLayout.LayoutParams.WRAP_CONTENT,
						(int) (40 * density)
						);
						btnParams.gravity = Gravity.END;
						btnParams.topMargin = (int) (20 * density);
						okButton.setLayoutParams(btnParams);
						
						// 🔹 Style tombol
						GradientDrawable btnBg = new GradientDrawable();
						btnBg.setCornerRadius(16 * density);
						btnBg.setColor(Color.parseColor("#4A148C"));
						btnBg.setStroke(3, Color.WHITE);
						
						okButton.setBackground(btnBg);
						
						// 🔹 Animasi tekan tombol
						okButton.setOnTouchListener(new View.OnTouchListener() {
							@Override
							public boolean onTouch(View btn, MotionEvent event) {
								switch (event.getAction()) {
									case MotionEvent.ACTION_DOWN:
									btn.animate().scaleX(0.8f).scaleY(0.8f).setDuration(100).start();
									break;
									case MotionEvent.ACTION_UP:
									case MotionEvent.ACTION_CANCEL:
									btn.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
									break;
								}
								return false;
							}
						});
						
						layout.addView(okButton);
						
						// 🔹 Dialog
						AlertDialog.Builder builder = new AlertDialog.Builder(EequipmentActivity.this);
						builder.setView(layout);
						
						final AlertDialog dialog = builder.create();
						dialog.show();
						
						dialog.setCancelable(true);
						dialog.setCanceledOnTouchOutside(true);
						
						// 🔹 Background dialog (HITAM + STROKE PUTIH)
						GradientDrawable bgDialog = new GradientDrawable();
						bgDialog.setCornerRadius(20 * density);
						bgDialog.setColor(Color.BLACK);
						bgDialog.setStroke(3, Color.WHITE);
						
						if (dialog.getWindow() != null) {
							dialog.getWindow().setBackgroundDrawable(bgDialog);
						}
						
						// 🔹 Klik tombol OK
						okButton.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View v) {
								dialog.dismiss();
							}
						});
						
					}
				}).start();
			}
		});
		
	} // Mematikan / menutup paksa metode onCreate asli Sketchware
	
	// Sekarang kita berada di level kelas, jadi aman mendaftarkan variabel global:
	private java.util.ArrayList<java.util.HashMap<String, Object>> _data;
	
	// Buka metode tiruan baru agar Sketchware tidak eror saat menulis tanda penutup otomatisnya:
	void metodeTiruanPenutup() {
		
	}
	
	
	@Override
	public void onResume() {
		super.onResume();
		final SharedPreferences prefs =
		getSharedPreferences("app_prefs", MODE_PRIVATE);
		
		long now = System.currentTimeMillis();
		long lastShown = prefs.getLong("lastAlertTime", 0);
		
		// Cooldown 10 detik
		if (now - lastShown < 10_000) {
			return;
		}
		
		// Tunda lebih lama supaya iklan tidak terganggu
		new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
			@Override
			public void run() {
				
				if (isFinishing() || isDestroyed()) return;
				
				// 🔒 Cek ringan & aman (urutan penting)
				boolean blocked = false;
				
				if (_isBlockedDNS()) {
					blocked = true;
				} else if (_isVPNEnabled()) {
					blocked = true;
				}
				// ❌ _checkAdBlock() sengaja DIHILANGKAN
				// karena berat & sering bikin delay
				
				if (blocked) {
					// ✅ Dialog muncul saat UI sudah stabil
					_showBlockDialog();
					
					prefs.edit()
					.putLong("lastAlertTime", System.currentTimeMillis())
					.apply();
				}
			}
		}, 3000);
	}
	public boolean _checkAdBlock() {
		if (_isVPNEnabled() || _isBlockedDNS()) {
			return true; // hanya kembalikan nilai
		}
		return false;
	}
	
	
	public boolean _isBlockedDNS() {
		try {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
				String mode = Settings.Global.getString(
				getContentResolver(),
				"private_dns_mode"
				);
				
				String host = Settings.Global.getString(
				getContentResolver(),
				"private_dns_specifier"
				);
				
				if ("hostname".equals(mode) && host != null) {
					host = host.toLowerCase();
					return host.contains("adguard")
					|| host.contains("nextdns")
					|| host.contains("blokada");
				}
			}
		} catch (Throwable ignored) {}
		return false;
	}
	
	
	public boolean _isVPNEnabled() {
		try {
			// ================================
			// 1) VPN RESMI (PALING AMAN)
			// ================================
			ConnectivityManager cm =
			(ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
			
			if (cm != null) {
				// 🟢 DIUBAH: Tambahkan android.net. di depan kata Network agar tidak ambigu
				android.net.Network network = cm.getActiveNetwork();
				NetworkCapabilities caps = cm.getNetworkCapabilities(network);
				
				if (caps != null &&
				caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
					return true;
				}
			}
			
			// ================================
			// 2) INTERFACE CHECK (BACKUP)
			// ================================
			for (NetworkInterface ni :
			java.util.Collections.list(NetworkInterface.getNetworkInterfaces())) {
				
				if (!ni.isUp() || ni.isLoopback()) continue;
				
				String name = ni.getName().toLowerCase(); // pakai getName(), lebih aman
				
				if (name.contains("tun")
				|| name.contains("wg")
				|| name.contains("ppp")) {
					
					return true;
				}
			}
			
			return false;
			
		} catch (Exception e) {
			return false;
		}
		
	}
	
	
	public void _showBlockDialog() {
		if (isFinishing() || isDestroyed()) return;
		
		androidx.appcompat.app.AlertDialog.Builder builder =
		new androidx.appcompat.app.AlertDialog.Builder(this);
		
		builder.setTitle("Koneksi Tidak Stabil • Unstable Connection");
		
		builder.setMessage(
		"Beberapa pengaturan jaringan atau DNS dapat memengaruhi " +
		"kestabilan koneksi aplikasi.\n\n" +
		"Jika Anda mengalami kendala, silakan nonaktifkan sementara " +
		"pengaturan tersebut lalu coba kembali.\n\n" +
		"Some network or DNS configurations may affect the app’s " +
		"connection stability.\n\n" +
		"If you experience issues, please temporarily disable such " +
		"settings and try again."
		);
		
		// ✅ Biarkan user bisa dismiss
		builder.setCancelable(true);
		
		// 🔁 COBA LAGI / RETRY
		builder.setPositiveButton("Coba Lagi / Retry",
		new android.content.DialogInterface.OnClickListener() {
			@Override
			public void onClick(android.content.DialogInterface dialog, int which) {
				
				dialog.dismiss();
				
				// Cek ulang DNS secara ringan
				if (!_isBlockedDNS()) {
					// lanjutkan aplikasi
					// contoh: loadData(); atau refresh halaman
				}
			}
		});
		
		// ⬅️ KEMBALI / BACK (lebih aman daripada force close)
		builder.setNegativeButton("Kembali / Back",
		new android.content.DialogInterface.OnClickListener() {
			@Override
			public void onClick(android.content.DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		
		builder.show();
		
	}
	
	
	public void _Anehgaminginejvtor(final ImageView _img, final String _file, final String _url) {
		Glide.with(getContext(this)).load(_url).thumbnail(Glide.with(getContext(this)).load(getContext(this).getResources().getIdentifier(_file, "drawable", getContext(this).getPackageName()))).fitCenter().into(_img);
	}
	public Context getContext(Context c) {
		return c;
	}
	public Context getContext(Fragment f) {
		return f.getActivity();
	}
	public Context getContext(DialogFragment df) {
		return df.getActivity();
	}
	{
	}
	
	
	public void _AnehGamingOfficial(final ArrayList<HashMap<String, Object>> _listmap, final String _aneh) {
		Comparator list_sorter = new Comparator<HashMap<String, Object>>(){
			@Override
			public int compare(HashMap<String, Object> map2, HashMap<String, Object> map1){
				
				try {
					Double num1 = Double.parseDouble(map1.get(_aneh).toString());
					Double num2 = Double.parseDouble(map2.get(_aneh).toString());
					return Double.compare(num2, num1);
				} catch (NumberFormatException e){
					return map2.get(_aneh).toString().compareTo(map1.get(_aneh).toString());
				}
				
			}
		};
		
		Collections.sort(_listmap, list_sorter);
	}
	
	public class Gridview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.equipment, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			// ========================================================
			// 🎨 1. GAMBAR LATAR BELAKANG KOTAK (BORDER PUTIH & LATAR HITAM)
			// ========================================================
			linear1.setBackground(new GradientDrawable() { 
				public GradientDrawable getIns(int a, int b, int c, int d) { 
					this.setCornerRadius(a); 
					this.setStroke(b, c); 
					this.setColor(d); 
					return this; 
				} 
			}.getIns((int)30, (int)3, 0xFFFFFFFF, 0xFF000000));
			
			// ========================================================
			// 🖼️ 2. PEMUATAN GAMBAR IKON ITEM (GLIDE)
			// ========================================================
			String urlGambar = _data.get((int)_position).get("item_icon").toString();
			
			Glide.with(getApplicationContext())
			.load(urlGambar)
			.placeholder(R.drawable.herokosong)
			.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners(25))
			.into(imageview1);
			
			// ========================================================
			// 📝 3. STRUKTUR TEKS UTAMA & EFEK TULISAN BERJALAN (MARQUEE)
			// ========================================================
			final int pos = _position;
			
			// 1. Reset animasi dan aktifkan status seleksi wajib agar Marquee XML berjalan
			textview1.clearAnimation();
			textview1.setSelected(true); 
			
			// 2. Setel paksa aturan scroll horizontal bawaan agar text running aktif sempurna
			textview1.setSingleLine(true);
			textview1.setHorizontallyScrolling(true);
			
			// 3. Pengaturan font kustom dan ukuran teks (Kode asli Anda)
			textview1.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/quick.ttf"), 1);
			textview1.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13);
			
			// 4. Masukkan data teks secara aman
			if (_data.get(pos).get("item_name") != null) {
				textview1.setText(String.valueOf(_data.get(pos).get("item_name")));
			} else {
				textview1.setText("");
			}
			
			
			// ========================================================
			// 📱 4. ANIMASI TEKAN EM PUK (IMAGEVIEW1)
			// ========================================================
			imageview1.setOnTouchListener((v, event) -> {
				if (event.getAction() == MotionEvent.ACTION_DOWN) {
					v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(100).start();
				} else if (event.getAction() == MotionEvent.ACTION_UP ||
				event.getAction() == MotionEvent.ACTION_CANCEL) {
					v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
				}
				return false;
			});
			
			imageview1.setOnClickListener(v -> {
				HashMap<String, Object> item = _data.get(pos);
				
				String name = String.valueOf(item.get("item_name") != null ? item.get("item_name") : "Equipment");
				String iconUrl = String.valueOf(item.get("item_icon") != null ? item.get("item_icon") : "");
				String attack = String.valueOf(item.get("stat_attack") != null ? item.get("stat_attack") : "");
				String speed = String.valueOf(item.get("stat_speed") != null ? item.get("stat_speed") : "");
				String lifesteal = String.valueOf(item.get("stat_lifesteal") != null ? item.get("stat_lifesteal") : ""); 
				String crit = String.valueOf(item.get("stat_crit") != null ? item.get("stat_crit") : ""); 
				String pTitle = String.valueOf(item.get("passive_title") != null ? item.get("passive_title") : "");
				String pDesc = String.valueOf(item.get("passive_desc") != null ? item.get("passive_desc") : "");
				
				// ========================================================
				// 🎨 1. LOGIKA PEWARNAAN MANDIRI ATRIBUT STATUS (STAT ATAS)
				// ========================================================
				
				// Pembersihan kode Enter bawaan dari database
				if (attack != null) attack = attack.replace("\\n", "<br>");
				if (speed != null) speed = speed.replace("\\n", "<br>");
				if (lifesteal != null) lifesteal = lifesteal.replace("\\n", "<br>");
				if (crit != null) crit = crit.replace("\\n", "<br>");
				
				// Pewarnaan Mandiri berdasarkan Jenis Atribut sebelum digabungkan
				String barisAttackHtml = "";
				if (attack != null && !attack.trim().isEmpty()) {
					barisAttackHtml = "<font color='#FFFFFF'><b>" + attack + "</b></font><br>";
				}
				
				String barisSpeedHtml = "";
				if (speed != null && !speed.trim().isEmpty()) {
					barisSpeedHtml = "<font color='#FFCC00'><b>" + speed + "</b></font><br>";
				}
				
				String barisLifestealHtml = "";
				if (lifesteal != null && !lifesteal.trim().isEmpty()) {
					barisLifestealHtml = "<font color='#D50000'><b>" + lifesteal + "</b></font><br>";
				}
				
				String barisCritHtml = "";
				if (crit != null && !crit.trim().isEmpty()) {
					barisCritHtml = "<font color='#FFCC00'><b>" + crit + "</b></font><br>";
				}
				
				// Gabungkan seluruh baris status atas yang sudah diwarnai secara mandiri
				String rawStatsCombined = barisAttackHtml + barisSpeedHtml + barisLifestealHtml + barisCritHtml;
				
				// ========================================================
				// 📝 2. PEMPROSESAN STRUKTUR TEKS DESKRIPSI PASIF BAWAAN
				// ========================================================
				String formattedDesc = pDesc
				.replace("\\n\\n", "<br><br>") 
				.replace("\\n", "<br>")         
				.replace("Increase", "<font color='#FFCC00'><b>Increase</b></font>")
				.replace("Meningkatkan", "<font color='#FFCC00'><b>Meningkatkan</b></font>");
				
				// ========================================================
				// 📱 3. PERAKITAN STRUKTUR DIALOG KUSTOM PREMIUM
				// ========================================================
				final android.app.Dialog dialog = new android.app.Dialog(v.getContext());
				dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
				
				android.widget.LinearLayout dialogLayout = new android.widget.LinearLayout(v.getContext());
				dialogLayout.setOrientation(android.widget.LinearLayout.VERTICAL);
				int paddingPro = (int) android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_DIP, 24, v.getContext().getResources().getDisplayMetrics());
				dialogLayout.setPadding(paddingPro, paddingPro, paddingPro, paddingPro);
				
				android.graphics.drawable.GradientDrawable borderDrawable = new android.graphics.drawable.GradientDrawable();
				borderDrawable.setColor(0xFF000000); 
				borderDrawable.setStroke(3, 0xFFFFFFFF); 
				borderDrawable.setCornerRadius(25); 
				dialogLayout.setBackground(borderDrawable);
				
				// Wadah Header Horizontal (Ikon Bulat + Judul)
				android.widget.LinearLayout headerLayout = new android.widget.LinearLayout(v.getContext());
				headerLayout.setOrientation(android.widget.LinearLayout.HORIZONTAL);
				headerLayout.setGravity(android.view.Gravity.CENTER_VERTICAL);
				
				android.widget.LinearLayout.LayoutParams headerParams = new android.widget.LinearLayout.LayoutParams(
				android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
				int marginSamping = (int) android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_DIP, 6, v.getContext().getResources().getDisplayMetrics());
				headerParams.setMargins(marginSamping, 0, marginSamping, (int) android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_DIP, 14, v.getContext().getResources().getDisplayMetrics()));
				headerLayout.setLayoutParams(headerParams);
				
				android.widget.ImageView dialogIcon = new android.widget.ImageView(v.getContext());
				int iconSize = (int) android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_DIP, 45, v.getContext().getResources().getDisplayMetrics());
				android.widget.LinearLayout.LayoutParams iconParams = new android.widget.LinearLayout.LayoutParams(iconSize, iconSize);
				iconParams.setMargins(0, 0, (int) android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_DIP, 10, v.getContext().getResources().getDisplayMetrics()), 0);
				dialogIcon.setLayoutParams(iconParams);
				
				com.bumptech.glide.Glide.with(v.getContext().getApplicationContext())
				.load(iconUrl)
				.placeholder(R.drawable.herokosong)
				.into(dialogIcon);
				headerLayout.addView(dialogIcon);
				
				android.widget.TextView tvTitle = new android.widget.TextView(v.getContext());
				tvTitle.setText(name);
				tvTitle.setTextSize(android.util.TypedValue.COMPLEX_UNIT_DIP, 18);
				tvTitle.setTextColor(0xFFFFFFFF); 
				tvTitle.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
				tvTitle.setLayoutParams(new android.widget.LinearLayout.LayoutParams(
				android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
				headerLayout.addView(tvTitle);
				
				dialogLayout.addView(headerLayout);
				
				// Wadah TextView Isi Konten Deskripsi
				android.widget.TextView tvContent = new android.widget.TextView(v.getContext());
				tvContent.setTextSize(android.util.TypedValue.COMPLEX_UNIT_DIP, 14);
				tvContent.setLineSpacing(0f, 1.2f); 
				
				android.widget.LinearLayout.LayoutParams contentParams = new android.widget.LinearLayout.LayoutParams(
				android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
				contentParams.setMargins(marginSamping, 0, marginSamping, 0); 
				tvContent.setLayoutParams(contentParams);
				
				// SUSUNAN STRUKTUR HTML AWHIR (GABUNGAN KONTEN KESELURUHAN)
				String htmlContent = rawStatsCombined 
				+ "<br><font color='#66BBFF'><b>" + pTitle + "</b></font>"
				+ "<font color='#FFFFFF'>" + formattedDesc + "</font>";
				
				// ========================================================
				// 🎨 4. GLOBAL REPLACER: CASE-INSENSITIVE (STAT + PASIF)
				// ========================================================
				
				// 🟢 Physical Defense & Shield / perisai -> Hijau Neon Cerah (#00E676)
				htmlContent = htmlContent.replaceAll("(?i)Physical Defense", "<font color='#00E676'><b>Physical Defense</b></font>")
				.replaceAll("(?i)Shield", "<font color='#00E676'><b>Shield</b></font>")
				.replaceAll("(?i)perisai", "<font color='#00E676'><b>perisai</b></font>");
				
				// 🔵 Magic Defense, Magic Power, Magic Penetration, Mana -> Biru Langit Elektrik (#00B0FF)
				htmlContent = htmlContent.replaceAll("(?i)Magic Defense", "<font color='#00B0FF'><b>Magic Defense</b></font>")
				.replaceAll("(?i)Magic Power", "<font color='#00B0FF'><b>Magic Power</b></font>")
				.replaceAll("(?i)Magic Penetration", "<font color='#00B0FF'><b>Magic Penetration</b></font>")
				.replaceAll("(?i)Mana", "<font color='#00B0FF'><b>Mana</b></font>");
				
				// 🔴 HP / hp -> Merah Lembut Terang (#FF3333)
				htmlContent = htmlContent.replaceAll("(?i)\\bHP\\b", "<font color='#FF3333'><b>HP</b></font>");
				
				// 🔴 Lifesteal / Hybrid Lifesteal / Spell Vamp -> Merah Pekat (#D50000)
				htmlContent = htmlContent.replaceAll("(?i)Lifesteal", "<font color='#D50000'><b>Lifesteal</b></font>")
				.replaceAll("(?i)Spell Vamp", "<font color='#D50000'><b>Spell Vamp</b></font>");
				
				// 🟠 Movement Speed / kecepatan gerak -> Jingga Emas (#FF9900)
				htmlContent = htmlContent.replaceAll("(?i)Movement Speed", "<font color='#FF9900'><b>Movement Speed</b></font>")
				.replaceAll("(?i)kecepatan gerak", "<font color='#FF9900'><b>kecepatan gerak</b></font>");
				
				// 🟡 Critical Chance / Critical Damage / Cooldown / Attack Speed -> Kuning Emas (#FFCC00) atau Hijau Cooldown
				htmlContent = htmlContent.replaceAll("(?i)Critical Chance", "<font color='#FFCC00'><b>Critical Chance</b></font>")
				.replaceAll("(?i)Critical Damage", "<font color='#FFCC00'><b>Critical Damage</b></font>")
				.replaceAll("(?i)Attack Speed", "<font color='#FFCC00'><b>Attack Speed</b></font>")
				.replaceAll("(?i)Cooldown Reduction", "</font><font color='#00E676'><b>Cooldown Reduction</b></font><font color='#FFCC00'>")
				.replaceAll("(?i)Cooldown", "</font><font color='#00E676'><b>Cooldown</b></font><font color='#FFCC00'>");
				
				// Pembersihan sisa-sisa baris kosong berlebih akibat gabungan data string kosong
				htmlContent = htmlContent.replace("<br><br><br>", "<br>").replace("<br><br>", "<br>");
				
				if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
					tvContent.setText(android.text.Html.fromHtml(htmlContent, android.text.Html.FROM_HTML_MODE_LEGACY));} else {tvContent.setText(android.text.Html.fromHtml(htmlContent));}dialogLayout.addView(tvContent);dialog.setContentView(dialogLayout);if (dialog.getWindow() != null) {dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));android.view.WindowManager.LayoutParams lp = new android.view.WindowManager.LayoutParams();lp.copyFrom(dialog.getWindow().getAttributes());lp.width = (int) (v.getContext().getResources().getDisplayMetrics().widthPixels * 0.85);lp.height = android.view.WindowManager.LayoutParams.WRAP_CONTENT;dialog.getWindow().setAttributes(lp);}dialog.setCanceledOnTouchOutside(true);dialog.show();});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}