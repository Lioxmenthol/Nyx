package com.nyx.tools.security;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

public class PremiumProgressDrawable extends Drawable {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int baseColor;
    private float progress = 0f;

    public PremiumProgressDrawable(int color) {
        this.baseColor = color;
        this.paint.setDither(true);
    }

    public void setProgressValue(float value) {
        this.progress = Math.max(0f, Math.min(100f, value));
        invalidateSelf();
    }

    @Override
    public void draw(Canvas canvas) {
        Rect bounds = getBounds();
        if (bounds.width() <= 0 || bounds.height() <= 0) return;

        float width = bounds.width();
        float height = bounds.height();
        float radius = height / 2f;

        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.parseColor("#66000000"));

        RectF fullRect = new RectF(bounds.left, bounds.top, bounds.right, bounds.bottom);
        canvas.drawRoundRect(fullRect, radius, radius, paint);

        float fillWidth = width * (progress / 100f);
        if (fillWidth <= 0f) return;

        RectF fillRect = new RectF(bounds.left, bounds.top, bounds.left + fillWidth, bounds.bottom);
        paint.setColor(baseColor);
        canvas.drawRoundRect(fillRect, radius, radius, paint);

        float circleRadius = Math.max(3f, height * 0.35f);
        float circleX = bounds.left + fillWidth;
        float circleY = bounds.top + (height / 2f);

        circleX = Math.max(bounds.left + circleRadius, Math.min(bounds.right - circleRadius, circleX));

        paint.setShader(null);
        paint.setColor(Color.WHITE);
        canvas.drawCircle(circleX, circleY, circleRadius + 1.5f, paint);

        paint.setColor(baseColor);
        canvas.drawCircle(circleX, circleY, circleRadius, paint);

        paint.setColor(Color.WHITE);
        canvas.drawCircle(circleX, circleY, circleRadius * 0.28f, paint);
    }

    @Override
    public void setAlpha(int alpha) {
        paint.setAlpha(alpha);
    }

    @Override
    public void setColorFilter(android.graphics.ColorFilter colorFilter) {
        paint.setColorFilter(colorFilter);
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
