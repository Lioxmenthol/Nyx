package com.nyx.tools;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;
import androidx.annotation.NonNull;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class ZeroAdsManager {

    // Cukup gunakan SATU variabel iklan saja untuk seluruh halaman aplikasi Anda
    public static InterstitialAd interstitialAd = null;
    private static boolean isLoading = false;

    // ID Iklan Interstitial Percobaan Google (Ganti ke ID asli Anda saat rilis)
    private static final String AD_UNIT_ID = "ca-app-pub-5321321373857819/1852961078";

    // 🚀 1. FUNGSI MUAT IKLAN DI LATAR BELAKANG (PRE-LOAD SUPER RINGKAS)
    public static void loadAd(final Context context) {
        if (interstitialAd != null || isLoading) {
            return; // Cegah spam request ganda
        }

        isLoading = true;
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(
                context.getApplicationContext(),
                AD_UNIT_ID,
                adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd ad) {
                        interstitialAd = ad;
                        isLoading = false;
                    }
                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError e) {
                        interstitialAd = null;
                        isLoading = false;
                    }
                }
        );
    }

    // 🚀 2. FUNGSI TAMPIL IKLAN UNIVERSAL UNTUK SEMUA HALAMAN (ANTI-SKIP API 36)
    public static void showAd(final Activity activity, final Runnable afterAdAction) {
        if (interstitialAd != null) {
            // ✅ FIX API 36: Full Path Callback terbukti sukses mengunci tombol back Android 16
            interstitialAd.setFullScreenContentCallback(new com.google.android.gms.ads.FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    interstitialAd = null; 
                    loadAd(activity); 
                    if (afterAdAction != null) afterAdAction.run(); 
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull com.google.android.gms.ads.AdError adError) { // ✅ FIX: Impor aman via Full Path
                    interstitialAd = null;
                    loadAd(activity);
                    if (afterAdAction != null) afterAdAction.run();
                }
            });
            interstitialAd.show(activity);
        } else {
            // FORCE LOAD & SHOW INSTAN JIKA IKLAN BELUM SIAP SAAT DIKLIK
            if (isLoading) {
                if (afterAdAction != null) afterAdAction.run();
                return;
            }

            Toast.makeText(activity.getApplicationContext(), "Sedang memproses...", Toast.LENGTH_SHORT).show();
            isLoading = true;
            AdRequest adRequest = new AdRequest.Builder().build();
            
            InterstitialAd.load(activity.getApplicationContext(), AD_UNIT_ID, adRequest, new InterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull InterstitialAd ad) {
                    interstitialAd = ad;
                    isLoading = false;
                    
                    // ✅ FIX API 36: Penyelarasan Full Path Callback pada blok Force Load
                    interstitialAd.setFullScreenContentCallback(new com.google.android.gms.ads.FullScreenContentCallback() {
                        @Override
                        public void onAdDismissedFullScreenContent() {
                            interstitialAd = null;
                            loadAd(activity);
                            if (afterAdAction != null) afterAdAction.run();
                        }
                        @Override
                        public void onAdFailedToShowFullScreenContent(@NonNull com.google.android.gms.ads.AdError adError) { // ✅ FIX: Impor aman via Full Path
                            interstitialAd = null;
                            loadAd(activity);
                            if (afterAdAction != null) afterAdAction.run();
                        }
                    });
                    
                    // ✅ FIX: Pastikan halaman masih aktif & tidak dihancurkan sebelum menampilkan force ad
                    if (!activity.isFinishing() && !activity.isDestroyed()) {
                        interstitialAd.show(activity);
                    }
                }
                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError e) {
                    interstitialAd = null;
                    isLoading = false;
                    if (afterAdAction != null) afterAdAction.run();
                }
            });
        }
    }
}
