package com.nyx.tools;

import android.net.Uri;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class MenuAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_HERO = 0;
    private static final int TYPE_MENU = 1;

    private final Context context;
    private ArrayList<HashMap<String, Object>> breh; 
    private String heroDetailJson;
    private int selectedHeroIndex = -1;




    public MenuAdapter(Context context, ArrayList<HashMap<String, Object>> dataList, String heroDetailJson) {
        this.context = context;
        this.breh = dataList;
        this.heroDetailJson = heroDetailJson;
    }

    public MenuAdapter(ArrayList<HashMap<String, Object>> dataList) {
        this.context = null;
        this.breh = dataList;
        this.heroDetailJson = "";
    }

    public void updateData(ArrayList<HashMap<String, Object>> newDataList, String newHeroDetailJson) {
        this.breh = newDataList;
        this.heroDetailJson = newHeroDetailJson;
        notifyDataSetChanged(); 
    }

    public void setHeroDetailJson(String json) {
        this.heroDetailJson = json == null ? "" : json;
        notifyItemChanged(0);
    }

    private void selectHeroFromSelector(int index) {
        if (!hasHeroDetail() || index < 0) return;
        try {
            ArrayList<HashMap<String, Object>> listHero = new Gson().fromJson(
                heroDetailJson,
                new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
            );
            if (listHero == null || index >= listHero.size()) return;
            selectedHeroIndex = index;
            notifyItemChanged(0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean hasHeroDetail() {
        return heroDetailJson != null && !heroDetailJson.isEmpty();
    }



    @Override
    public int getItemCount() {
        int menuCount = breh != null ? breh.size() : 0;
        return menuCount + (hasHeroDetail() ? 1 : 0);
    }

    @Override
    public int getItemViewType(int position) {
        if (hasHeroDetail() && position == 0) return TYPE_HERO;
        return TYPE_MENU;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == TYPE_HERO) {
            FrameLayout container = new FrameLayout(parent.getContext());
            container.setLayoutParams(new RecyclerView.LayoutParams(
                    RecyclerView.LayoutParams.MATCH_PARENT,
                    RecyclerView.LayoutParams.WRAP_CONTENT
            ));
            container.setBackgroundColor(Color.TRANSPARENT);
            return new HeroViewHolder(container);
        }
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.menuzero, parent, false);
        return new MenuViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (getItemViewType(position) == TYPE_HERO) {
            bindHeroDetail((HeroViewHolder) holder);
            return;
        }
        int menuPosition = hasHeroDetail() ? position - 1 : position;
        if (breh == null || menuPosition < 0 || menuPosition >= breh.size() || breh.get(menuPosition) == null) return;
        bindMenu((MenuViewHolder) holder, menuPosition);
    }



    private void bindHeroDetail(HeroViewHolder holder) {
        try {
            holder.container.removeAllViews();
            holder.container.setBackgroundColor(Color.TRANSPARENT);
            if (!hasHeroDetail()) { holder.container.setVisibility(View.GONE); return; }

            ArrayList<HashMap<String, Object>> listHero = new Gson().fromJson(
                heroDetailJson,
                new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType()
            );
            if (listHero == null || listHero.size() == 0) { holder.container.setVisibility(View.GONE); return; }

            if (selectedHeroIndex < 0 || selectedHeroIndex >= listHero.size()) {
                selectedHeroIndex = new Random().nextInt(listHero.size());
            }

            HashMap<String, Object> heroData = listHero.get(selectedHeroIndex);
            if (heroData == null) { holder.container.setVisibility(View.GONE); return; }

            View vKustom = LayoutInflater.from(context).inflate(R.layout.herodetail, holder.container, false);
            try {
                if (vKustom instanceof ViewGroup) {
                    PackageWarningHelper warningHelper = new PackageWarningHelper(context);
                    warningHelper.attachTo((ViewGroup) vKustom);
                }
            } catch (Exception e) { e.printStackTrace(); }

            TextView txtHeroRole = vKustom.findViewById(R.id.heroRole);
            TextView tDurP = vKustom.findViewById(R.id.textDurabilityPercent);
            TextView tOffP = vKustom.findViewById(R.id.textOffensePercent);
            TextView tCtrlP = vKustom.findViewById(R.id.textControlPercent);
            TextView tDiffP = vKustom.findViewById(R.id.textDifficultyPercent);
            ProgressBar pDur = vKustom.findViewById(R.id.progressDurability);
            ProgressBar pOff = vKustom.findViewById(R.id.progressOffense);
            ProgressBar pCtrl = vKustom.findViewById(R.id.progressControl);
            ProgressBar pDiff = vKustom.findViewById(R.id.progressDifficulty);
            ImageView imgHero = vKustom.findViewById(R.id.imageview2);
            ImageView sPasif = vKustom.findViewById(R.id.imgSkillPasif);
            ImageView s1 = vKustom.findViewById(R.id.imgSkill1);
            ImageView s2 = vKustom.findViewById(R.id.imgSkill2);
            ImageView sUlt = vKustom.findViewById(R.id.imgSkillUlt);
            View stats = vKustom.findViewById(R.id.layoutHeroStats);
            if (stats != null) stats.setBackgroundColor(Color.TRANSPARENT);

            View skillTitle = vKustom.findViewById(R.id.layoutSkillTitle);
            View skillDesc = vKustom.findViewById(R.id.layoutSkillDesc);
            View bestBuild = vKustom.findViewById(R.id.layoutBestBuild);
            if (skillTitle != null) skillTitle.setVisibility(View.GONE);
            if (skillDesc != null) skillDesc.setVisibility(View.GONE);
            if (bestBuild != null) bestBuild.setVisibility(View.GONE);

            hideDefaultTextViews(vKustom, txtHeroRole, tDurP, tOffP, tCtrlP, tDiffP);

            if (txtHeroRole != null) {
                String namaHero = heroData.containsKey("her") ? String.valueOf(heroData.get("her")) : "Hero";
                String roleHero = heroData.containsKey("roll") ? String.valueOf(heroData.get("roll")) : "";
                txtHeroRole.setText(namaHero + "\n" + roleHero);
                txtHeroRole.setTextColor(Color.WHITE);
            }

            int durability = 0, offense = 0, control = 0, difficulty = 0;
            try { durability = (int) Double.parseDouble(String.valueOf(heroData.get("stat_durability")).trim()); } catch (Exception e) {}
            try { offense = (int) Double.parseDouble(String.valueOf(heroData.get("stat_offense")).trim()); } catch (Exception e) {}
            try { control = (int) Double.parseDouble(String.valueOf(heroData.get("stat_control")).trim()); } catch (Exception e) {}
            try { difficulty = (int) Double.parseDouble(String.valueOf(heroData.get("stat_difficulty")).trim()); } catch (Exception e) {}

            if (tDurP != null) tDurP.setText("Ketahanan  " + durability + "%");
            if (tOffP != null) tOffP.setText("Serangan  " + offense + "%");
            if (tCtrlP != null) tCtrlP.setText("Efek Kontrol  " + control + "%");
            if (tDiffP != null) tDiffP.setText("Kesulitan  " + difficulty + "%");

            if (pDur != null) {
                pDur.setMax(100); pDur.setProgressDrawable(new PremiumProgressDrawable(context, Color.parseColor("#00C853"), Color.parseColor("#39FF14"), Color.parseColor("#76FF03"))); pDur.setProgress(0);
                android.animation.ObjectAnimator.ofInt(pDur, "progress", 0, durability).setDuration(850).start();
            }
            if (pOff != null) {
                pOff.setMax(100); pOff.setProgressDrawable(new PremiumProgressDrawable(context, Color.parseColor("#D50000"), Color.parseColor("#FF1744"), Color.parseColor("#FF5252"))); pOff.setProgress(0);
                android.animation.ObjectAnimator.ofInt(pOff, "progress", 0, offense).setDuration(850).start();
            }
            if (pCtrl != null) {
                pCtrl.setMax(100); pCtrl.setProgressDrawable(new PremiumProgressDrawable(context, Color.parseColor("#0066CC"), Color.parseColor("#2196F3"), Color.parseColor("#40C4FF"))); pCtrl.setProgress(0);
                android.animation.ObjectAnimator.ofInt(pCtrl, "progress", 0, control).setDuration(850).start();
            }
            if (pDiff != null) {
                pDiff.setMax(100); pDiff.setProgressDrawable(new PremiumProgressDrawable(context, Color.parseColor("#7B1FA2"), Color.parseColor("#D500F9"), Color.parseColor("#EA80FC"))); pDiff.setProgress(0);
                android.animation.ObjectAnimator.ofInt(pDiff, "progress", 0, difficulty).setDuration(850).start();
            }

            if (imgHero != null) {
                imgHero.setScaleType(ImageView.ScaleType.FIT_XY);
                float density = context.getResources().getDisplayMetrics().density;
                final int radius = (int)(12 * density);
                imgHero.setBackgroundColor(Color.TRANSPARENT);
                GradientDrawable heroStroke = new GradientDrawable(); heroStroke.setColor(Color.TRANSPARENT); heroStroke.setCornerRadius(radius); heroStroke.setStroke((int)(2 * density), Color.parseColor("#FFFFFF"));
                imgHero.setForeground(heroStroke); imgHero.setClipToOutline(true);

                String urlHero = heroData.containsKey("URL") ? String.valueOf(heroData.get("URL")) : "";
                if (!urlHero.isEmpty()) { Glide.with(context).load(urlHero).placeholder(R.drawable.herokosong).error(R.drawable.herokosong).transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners(radius)).into(imgHero); } 
                else { imgHero.setImageResource(R.drawable.herokosong); }
            }

            if (sPasif != null && heroData.containsKey("skill_pasif_URL")) Glide.with(context).load(String.valueOf(heroData.get("skill_pasif_URL"))).placeholder(R.drawable.herokosong).transform(new com.bumptech.glide.load.resource.bitmap.CircleCrop()).into(sPasif);
            if (s1 != null && heroData.containsKey("skill1_URL")) Glide.with(context).load(String.valueOf(heroData.get("skill1_URL"))).placeholder(R.drawable.herokosong).transform(new com.bumptech.glide.load.resource.bitmap.CircleCrop()).into(s1);
            if (s2 != null && heroData.containsKey("skill2_URL")) Glide.with(context).load(String.valueOf(heroData.get("skill2_URL"))).placeholder(R.drawable.herokosong).transform(new com.bumptech.glide.load.resource.bitmap.CircleCrop()).into(s2);
            if (sUlt != null && heroData.containsKey("skill_ult_URL")) Glide.with(context).load(String.valueOf(heroData.get("skill_ult_URL"))).placeholder(R.drawable.herokosong).transform(new com.bumptech.glide.load.resource.bitmap.CircleCrop()).into(sUlt);
            
            View.OnTouchListener skillTouch = (v, e) -> {
                if (e.getAction() == MotionEvent.ACTION_DOWN) v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(80).start();
                if (e.getAction() == MotionEvent.ACTION_CANCEL || e.getAction() == MotionEvent.ACTION_UP) {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(80).start();
                    if (e.getAction() == MotionEvent.ACTION_UP) tampilkanSkill(heroData, v.getId());
                }
                return true;
            };

            if (sPasif != null) sPasif.setOnTouchListener(skillTouch);
            if (s1 != null) s1.setOnTouchListener(skillTouch);
            if (s2 != null) s2.setOnTouchListener(skillTouch);
            if (sUlt != null) sUlt.setOnTouchListener(skillTouch);

            addHeroSelector(vKustom, sUlt, listHero);
            vKustom.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
            holder.container.addView(vKustom);
            holder.container.setVisibility(View.VISIBLE);
        } catch (Exception e) { e.printStackTrace(); holder.container.removeAllViews(); }
    }



    private void addHeroSelector(View root, View skillAnchor, ArrayList<HashMap<String, Object>> listHero) {
        try {
            if (!(root instanceof ViewGroup) || listHero == null || listHero.size() == 0) return;
            final ViewGroup rootGroup = (ViewGroup) root;
            float density = context.getResources().getDisplayMetrics().density;

            View oldSelector = rootGroup.findViewWithTag("ZERO_HERO_SELECTOR");
            if (oldSelector != null) {
                ViewParent parent = oldSelector.getParent();
                if (parent instanceof ViewGroup) ((ViewGroup) parent).removeView(oldSelector);
            }

            RecyclerView heroRecycler = new RecyclerView(context);
            heroRecycler.setTag("ZERO_HERO_SELECTOR");
            heroRecycler.setLayoutManager(new androidx.recyclerview.widget.LinearLayoutManager(context, androidx.recyclerview.widget.LinearLayoutManager.HORIZONTAL, false));
            heroRecycler.setHasFixedSize(true); heroRecycler.setNestedScrollingEnabled(false); heroRecycler.setOverScrollMode(View.OVER_SCROLL_NEVER);

            LinearLayout.LayoutParams rvParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (int)(98 * density));
            rvParams.topMargin = 0; rvParams.bottomMargin = (int)(18 * density);
            heroRecycler.setLayoutParams(rvParams);
            
            HeroSelectorAdapter selectorAdapter = new HeroSelectorAdapter(context, listHero);
            heroRecycler.setAdapter(selectorAdapter);

            ViewGroup targetParent = null; int targetIndex = -1;
            if (skillAnchor != null) {
                View current = skillAnchor;
                while (current.getParent() instanceof ViewGroup) {
                    ViewParent vp = current.getParent(); ViewGroup parent = (ViewGroup) vp;
                    if (parent instanceof LinearLayout && ((LinearLayout) parent).getOrientation() == LinearLayout.VERTICAL) {
                        targetParent = parent; targetIndex = parent.indexOfChild(current) + 1; break;
                    }
                    current = parent;
                }
            }
            if (targetParent == null) { targetParent = rootGroup; targetIndex = targetParent.getChildCount(); }
            targetParent.addView(heroRecycler, targetIndex);

            final int activeIndex = selectedHeroIndex;
            if (activeIndex >= 0 && activeIndex < listHero.size()) {
                heroRecycler.postDelayed(() -> {
                    try { heroRecycler.smoothScrollToPosition(activeIndex); } catch (Exception e) { heroRecycler.scrollToPosition(activeIndex); }
                }, 80);
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void hideDefaultTextViews(View root, TextView heroRole, TextView durability, TextView offense, TextView control, TextView difficulty) {
        if (!(root instanceof ViewGroup)) return;
        ViewGroup group = (ViewGroup) root;
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            if (child instanceof TextView) {
                TextView tv = (TextView) child;
                if (tv == heroRole || tv == durability || tv == offense || tv == control || tv == difficulty) continue;
                if ("TextView".equalsIgnoreCase(tv.getText() == null ? "" : tv.getText().toString().trim())) tv.setVisibility(View.GONE);
            } else if (child instanceof ViewGroup) {
                hideDefaultTextViews(child, heroRole, durability, offense, control, difficulty);
            }
        }
    }

    private void tampilkanSkill(HashMap<String, Object> heroData, int viewId) {
        try {
            String fd = heroData.containsKey("skill_desc") ? String.valueOf(heroData.get("skill_desc")) : "";
            String j = "Skill", d = "Deskripsi tidak tersedia.";

            if (viewId == R.id.imgSkillPasif) {
                String[] b = fd.split("🔵");
                if (b.length > 0) { d = b[0].replace("🔴", "").trim(); String[] br = d.split("\n"); if (br.length > 0) j = br[0].replace("PASIF - ", "").replace(":", "").trim(); }
                com.nyx.tools.security.JsonManager.tampilkanSkillPopup((MainActivity) context, j, d, String.valueOf(heroData.get("skill_pasif_URL")));
            }
            if (viewId == R.id.imgSkill1) {
                String[] b1 = fd.split("🔵");
                if (b1.length > 1) { String[] b2 = b1[1].split("🟡"); if (b2.length > 0) { d = b2[0].trim(); String[] br = d.split("\n"); if (br.length > 0) j = br[0].replace("SKILL 1 - ", "").replace(":", "").trim(); } }
                com.nyx.tools.security.JsonManager.tampilkanSkillPopup((MainActivity) context, j, d, String.valueOf(heroData.get("skill1_URL")));
            }
            if (viewId == R.id.imgSkill2) {
                String[] b1 = fd.split("🟡");
                if (b1.length > 1) { String[] b2 = b1[1].split("💜"); if (b2.length > 0) { d = b2[0].trim(); String[] br = d.split("\n"); if (br.length > 0) j = br[0].replace("SKILL 2 - ", "").replace(":", "").trim(); } }
                com.nyx.tools.security.JsonManager.tampilkanSkillPopup((MainActivity) context, j, d, String.valueOf(heroData.get("skill2_URL")));
            }
            if (viewId == R.id.imgSkillUlt) {
                String[] b = fd.split("💜");
                if (b.length > 1) { d = b[1].trim(); String[] br = d.split("\n"); if (br.length > 0) j = br[0].replaceAll("ULTIMATE \\(SKILL \\d+\\) - ", "").replace(":", "").trim(); }
                com.nyx.tools.security.JsonManager.tampilkanSkillPopup((MainActivity) context, j, d, String.valueOf(heroData.get("skill_ult_URL")));
            }
        } catch (Exception e) {}
    }



        // ========================================================
    // 📡 FIXED BIND MENU — SINKRONISASI INTENT DAN LISTENER KLIK
    // ========================================================
    private void bindMenu(MenuViewHolder holder, int currentPos) {
        if (breh == null || currentPos < 0 || currentPos >= breh.size()) return;
        final HashMap<String, Object> menuData = breh.get(currentPos);
        final Context ctx = holder.itemView.getContext();

        ViewGroup.LayoutParams lp = holder.itemView.getLayoutParams();
        if (lp instanceof RecyclerView.LayoutParams) {
            RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) lp;
            params.height = RecyclerView.LayoutParams.WRAP_CONTENT; params.setMargins(0, 0, 0, 9);
            holder.itemView.setLayoutParams(params);
        }

        // Render Icon Kiri dan Kanan dari data Github/Server
        if (menuData.containsKey("menu_icon_left") && menuData.get("menu_icon_left") != null) {
            Glide.with(context).load(String.valueOf(menuData.get("menu_icon_left"))).placeholder(R.drawable.herokosong).transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners(25)).into(holder.imageview1);
        }
        if (menuData.containsKey("menu_icon_right") && menuData.get("menu_icon_right") != null) {
            Glide.with(context).load(String.valueOf(menuData.get("menu_icon_right"))).placeholder(R.drawable.herokosong).transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners(25)).into(holder.imageview2);
        }

        holder.textview1.clearAnimation(); holder.textview2.clearAnimation();
        holder.textview1.setSelected(true); holder.textview2.setSelected(true);
        holder.textview1.setText(menuData.containsKey("menu_title") && menuData.get("menu_title") != null ? String.valueOf(menuData.get("menu_title")) : "");
        holder.textview2.setText(menuData.containsKey("menu_sub") && menuData.get("menu_sub") != null ? String.valueOf(menuData.get("menu_sub")) : "");

        holder.linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns(30, 3, 0xFFFFFFFF, 0xFF000000));
        
        // Efek Animasi Tekan Item Menu Utama
        holder.linear1.setOnTouchListener((v, ev) -> {
            if (ev.getAction() == MotionEvent.ACTION_DOWN) v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start();
            if (ev.getAction() == MotionEvent.ACTION_UP || ev.getAction() == MotionEvent.ACTION_CANCEL) v.animate().scaleX(1f).scaleY(1f).setDuration(150).start();
            return false;
        });

        // ========================================================
        // 🔥 LOGIKA PEMROSESAN KLIK MENU UTAMA (SINKRON VARIABEL)
        // ========================================================
        holder.linear1.setOnClickListener(_view -> {
            String target = String.valueOf(menuData.get("target_page") != null ? menuData.get("target_page") : "");
            
            SharedPreferences sp = ctx.getSharedPreferences("sp", Context.MODE_PRIVATE);
            if (menuData.containsKey("menu_title") && menuData.get("menu_title") != null) {
                sp.edit().putString("her", String.valueOf(menuData.get("menu_title"))).apply();
            }

            Intent intent = new Intent(); 
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            // Jalankan perpindahan Activity internal aplikasi
            if ("AllskinActivity".equals(target)) { 
                intent.setClass(ctx.getApplicationContext(), AllskinActivity.class); 
                ctx.startActivity(intent); 
            } 
            else if ("EequipmentActivity".equals(target)) { 
                intent.setClass(ctx.getApplicationContext(), EequipmentActivity.class); 
                ctx.startActivity(intent); 
            } 
            else if ("CalculatorActivity".equals(target)) { 
                intent.setClass(ctx.getApplicationContext(), CalculatorActivity.class); 
                ctx.startActivity(intent); 
            }
            // Jalankan pembukaan tautan platform eksternal (WA, Admin, Youtube)
            else if ("_group".equals(target)) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://chat.whatsapp.com/LdFrdpAX4gP5xLjoGYzAsS?s=cl&p=a&iam=2"));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(i);
            } 
            else if ("_cs".equals(target)) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/+6283842778395"));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(i);
            } 
            else if ("_tutorial".equals(target)) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/playlist?list=PL3fU1kworLKPIT97AfWDdqXX6Ni68HgyH&si=fH8c0swby_muFV8d"));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(i);
            }
        }); // <- Penutup Klik Listener yang sah, seluruh variabel kini aman terbungkus di dalam!
    }




    public static class HeroViewHolder extends RecyclerView.ViewHolder { 
        FrameLayout container; 
        public HeroViewHolder(@NonNull View view) { 
            super(view); 
            container = (FrameLayout) view; 
        } 
    }
    
    public static class MenuViewHolder extends RecyclerView.ViewHolder { 
        LinearLayout linear1; 
        ImageView imageview1, imageview2; 
        TextView textview1, textview2; 
        public MenuViewHolder(@NonNull View view) { 
            super(view); 
            linear1 = view.findViewById(R.id.linear1); 
            imageview1 = view.findViewById(R.id.imageview1); 
            imageview2 = view.findViewById(R.id.imageview2); 
            textview1 = view.findViewById(R.id.textview1); 
            textview2 = view.findViewById(R.id.textview2); 
            textview1.setSingleLine(true); textview2.setSingleLine(true); 
            textview1.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20); textview2.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12); 
            textview1.setTextColor(Color.WHITE); textview2.setTextColor(Color.WHITE); 
            try { 
                Typeface f = Typeface.createFromAsset(view.getContext().getAssets(), "fonts/quick.ttf"); 
                textview1.setTypeface(f, Typeface.BOLD); textview2.setTypeface(f, Typeface.BOLD); 
            } catch (Exception e) {} 
        } 
    }



    private class HeroSelectorAdapter extends RecyclerView.Adapter<HeroSelectorAdapter.HeroSelectorHolder> {
        private final Context ctx; private final ArrayList<HashMap<String, Object>> heroes;
        HeroSelectorAdapter(Context ctx, ArrayList<HashMap<String, Object>> heroes) { this.ctx = ctx; this.heroes = heroes; }
        @NonNull @Override public HeroSelectorHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            float density = ctx.getResources().getDisplayMetrics().density; LinearLayout item = new LinearLayout(ctx); item.setOrientation(LinearLayout.VERTICAL); item.setGravity(android.view.Gravity.CENTER); item.setPadding((int)(4 * density), 0, (int)(4 * density), 0);
            item.setLayoutParams(new RecyclerView.LayoutParams((int)(94 * density), RecyclerView.LayoutParams.MATCH_PARENT));
            FrameLayout imageFrame = new FrameLayout(ctx); ImageView image = new ImageView(ctx); image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setLayoutParams(new FrameLayout.LayoutParams((int)(74 * density), (int)(74 * density), android.view.Gravity.CENTER));
            GradientDrawable imageClip = new GradientDrawable(); imageClip.setColor(Color.TRANSPARENT); imageClip.setCornerRadius((int)(17 * density)); image.setBackground(imageClip); image.setClipToOutline(true);
            TextView name = new TextView(ctx); name.setTextColor(Color.WHITE); name.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10); name.setGravity(android.view.Gravity.CENTER); name.setSingleLine(true); name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            imageFrame.addView(image); item.addView(imageFrame, new LinearLayout.LayoutParams((int)(82 * density), (int)(82 * density))); item.addView(name); return new HeroSelectorHolder(item, imageFrame, image, name);
        }
        
                @Override
        public void onBindViewHolder(@NonNull HeroSelectorHolder holder, int position) {
            if (position < 0 || position >= heroes.size()) return;
            HashMap<String, Object> hero = heroes.get(position);
            if (hero == null) return;

            // Set Nama Hero
            holder.name.setText(hero.containsKey("her") && hero.get("her") != null ? String.valueOf(hero.get("her")) : "Hero");
            String url = hero.containsKey("URL") && hero.get("URL") != null ? String.valueOf(hero.get("URL")) : "";
            
            boolean selected = position == selectedHeroIndex;
            float density = ctx.getResources().getDisplayMetrics().density;
            final int strokeWidth = selected ? (int)(3.5f * density) : (int)(1.5f * density);

            // ========================================================
            // FIX STROKE BULAT SEMPURNA (MENGGUNAKAN BENTUK OVAL)
            // ========================================================
            holder.image.setPadding(0, 0, 0, 0);
            GradientDrawable imageClip = new GradientDrawable();
            imageClip.setShape(GradientDrawable.OVAL); // Mengunci mutlak ke bentuk lingkaran
            imageClip.setColor(Color.TRANSPARENT);
            holder.image.setBackground(imageClip);
            holder.image.setClipToOutline(true);

            // Frame Luar Pengatur Border/Stroke Ungu & Putih
            GradientDrawable border = new GradientDrawable();
            border.setShape(GradientDrawable.OVAL); // Frame luar juga wajib OVAL
            border.setColor(Color.TRANSPARENT);
            border.setStroke(
                strokeWidth,
                selected ? Color.parseColor("#4A148C") : Color.parseColor("#FFFFFF")
                );
            
            holder.imageFrame.setBackgroundColor(Color.TRANSPARENT);
            holder.imageFrame.setForeground(border);

            // Muat Gambar Menggunakan CircleCrop dari Glide agar sinkron dengan Bingkainya
            if (!url.isEmpty()) {
                Glide.with(ctx)
                        .load(url)
                        .placeholder(R.drawable.herokosong)
                        .error(R.drawable.herokosong)
                        .transform(new com.bumptech.glide.load.resource.bitmap.CircleCrop()) // Ubah ke CircleCrop
                        .into(holder.image);
            } else {
                holder.image.setImageResource(R.drawable.herokosong);
            }

            // Aksi Klik Pilih Hero
            holder.itemView.setOnClickListener(v -> MenuAdapter.this.selectHeroFromSelector(position));
        }


        @Override public int getItemCount() { return heroes != null ? heroes.size() : 0; }
        class HeroSelectorHolder extends RecyclerView.ViewHolder { FrameLayout imageFrame; ImageView image; TextView name; HeroSelectorHolder(@NonNull View itemView, FrameLayout imageFrame, ImageView image, TextView name) { super(itemView); this.imageFrame = imageFrame; this.image = image; this.name = name; } }
    }



    private static class PremiumProgressDrawable extends android.graphics.drawable.Drawable {
        private final android.graphics.Paint backgroundPaint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG); private final android.graphics.Paint fillPaint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG); private final android.graphics.Paint shinePaint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG); private final android.graphics.Paint borderPaint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG); private final android.graphics.Paint glowPaint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG); private final android.graphics.RectF rect = new android.graphics.RectF(); private final android.graphics.RectF fillRect = new android.graphics.RectF(); private final android.content.Context ctx; private final int colorStart, colorMain, colorEnd; private float shimmerPosition = 0f;
        PremiumProgressDrawable(android.content.Context context, int startColor, int mainColor, int endColor) {
            this.ctx = context; this.colorStart = startColor; this.colorMain = mainColor; this.colorEnd = endColor;
            backgroundPaint.setStyle(android.graphics.Paint.Style.FILL); fillPaint.setStyle(android.graphics.Paint.Style.FILL); shinePaint.setStyle(android.graphics.Paint.Style.FILL); borderPaint.setStyle(android.graphics.Paint.Style.STROKE); borderPaint.setStrokeWidth(dp(1)); borderPaint.setColor(android.graphics.Color.argb(170, 255, 255, 255)); glowPaint.setStyle(android.graphics.Paint.Style.FILL);
            android.animation.ValueAnimator anim = android.animation.ValueAnimator.ofFloat(-0.20f, 1.20f); anim.setDuration(1450); anim.setRepeatCount(android.animation.ValueAnimator.INFINITE); anim.addUpdateListener(animation -> { shimmerPosition = (Float) animation.getAnimatedValue(); invalidateSelf(); }); anim.start();
        }
        private float dp(float value) { return ctx == null ? value : value * ctx.getResources().getDisplayMetrics().density; }
        @Override public void draw(android.graphics.Canvas canvas) {
            android.graphics.Rect bounds = getBounds(); if (bounds.width() <= 0 || bounds.height() <= 0) return;
            float left = bounds.left, top = bounds.top, right = bounds.right, bottom = bounds.bottom, width = right - left, height = bottom - top, radius = height / 2f;
            backgroundPaint.setColor(android.graphics.Color.parseColor("#101923")); rect.set(left, top, right, bottom); canvas.drawRoundRect(rect, radius, radius, backgroundPaint);
            float progress = getLevel() / 10000f;
            if (progress > 0f) {
                float fillWidth = width * progress; if (fillWidth < dp(2)) fillWidth = dp(2); fillRect.set(left, top, Math.min(right, left + fillWidth), bottom);
                fillPaint.setShader(new android.graphics.LinearGradient(left, top, right, bottom, new int[]{colorStart, colorMain, colorEnd}, new float[]{0f, 0.55f, 1f}, android.graphics.Shader.TileMode.CLAMP)); canvas.save();
                android.graphics.Path clipPath = new android.graphics.Path(); clipPath.addRoundRect(fillRect, radius, radius, android.graphics.Path.Direction.CW); canvas.clipPath(clipPath); canvas.drawRect(fillRect, fillPaint);
                float shineCenter = left + fillWidth * shimmerPosition, shineWidth = Math.max(dp(16), Math.min(dp(34), fillWidth * 0.18f));
                shinePaint.setShader(new android.graphics.LinearGradient(shineCenter - shineWidth, top, shineCenter + shineWidth, bottom, new int[]{android.graphics.Color.TRANSPARENT, android.graphics.Color.argb(235, 255, 255, 255), android.graphics.Color.TRANSPARENT}, new float[]{0f, 0.5f, 1f}, android.graphics.Shader.TileMode.CLAMP)); canvas.drawRect(left, top, right, bottom, shinePaint); canvas.restore();
                fillPaint.setShader(null); shinePaint.setShader(null); glowPaint.setColor(android.graphics.Color.argb(95, 255, 255, 255)); canvas.drawCircle(left + fillWidth, top + height / 2f, Math.max(dp(5), height * 0.42f), glowPaint);
            }
            canvas.drawRoundRect(rect, radius, radius, borderPaint);
        }
        @Override protected boolean onLevelChange(int lvl) { invalidateSelf(); return true; }
        @Override public void setAlpha(int a) {}
        @Override public void setColorFilter(android.graphics.ColorFilter f) {}
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }
}