package com.nyx.tools;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.net.Uri;
import android.os.Build;
import android.provider.DocumentsContract;
import android.widget.Toast;

import androidx.documentfile.provider.DocumentFile;

import java.io.FileNotFoundException;

public class PermissionManager {

    private Activity activity;
    private SharedPreferences sp;

    public static final int NEW_FOLDER_REQUEST_CODE = 1001;

    public PermissionManager(Activity activity) {
        this.activity = activity;
        
        // Membaca SharedPreferences utama dari activity agar selaras dengan Sketchware
        sp = activity.getSharedPreferences(
                activity.getPackageName() + "_preferences", 
                Activity.MODE_PRIVATE
        );
    }

    // ===============================
    // REQUEST SAF (FIXED: SEKARANG TEMBUS)
    // ===============================
    public void RequestDataPermission() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION |
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            );

            // AMBIL URI TRICK DARI FUNGSI DI BAWAH
            Uri targetUri = Uri.parse(GetDataUri());

            // FIX: WAJIB MASUKKAN INITIAL URI AGAR SAF LANGSUNG MEMBUKA FOLDER ML
            intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, targetUri);

            activity.startActivityForResult(intent, NEW_FOLDER_REQUEST_CODE);
        } catch (Exception e) {
            Toast.makeText(activity, e.toString(), Toast.LENGTH_LONG).show();
        }
    }

    // ===============================
    // CHECK PERMISSION VALID
    // ===============================
    public boolean IsPermissionGranted() {
        // Disinkronkan menggunakan key "D_URI" sesuai standar data tembus Anda
        String uriString = sp.getString("D_URI", "");
        if (uriString == null || uriString.isEmpty()) return false;

        try {
            Uri uri = Uri.parse(uriString);
            for (UriPermission p : activity.getContentResolver().getPersistedUriPermissions()) {
                if (p.getUri() != null && uri != null && uri.toString().startsWith(p.getUri().toString())) {
                    if (p.isWritePermission()) return true;
                }
            }
        } catch (Exception ignored) {}
        return false;
    }

    // ===============================
    // DETECT ML PACKAGE (LENGKAP SELURUH DUNIA)
    // ===============================
    private String getMlPackage() {
        // 1. Versi Global (Umum, Indonesia, Filipina, Arab, Malaysia, dll)
        try {
            activity.getPackageManager().getPackageInfo("com.mobile.legends", 0);
            return "com.mobile.legends";
        } catch (Exception ignored) {}

        // 2. Versi Vietnam (Diterbitkan resmi oleh VNG)
        try {
            activity.getPackageManager().getPackageInfo("com.vng.mlbbvn", 0);
            return "com.vng.mlbbvn";
        } catch (Exception ignored) {}

        // 3. Versi Amerika Serikat / Amerika Utara (Skystone)
        try {
            activity.getPackageManager().getPackageInfo("com.mobile.legends.usa", 0);
            return "com.mobile.legends.usa";
        } catch (Exception ignored) {}

        // 4. Versi India lama / Alternatif Xiaomi Store
        try {
            activity.getPackageManager().getPackageInfo("com.mobilelegends.mi", 0);
            return "com.mobilelegends.mi";
        } catch (Exception ignored) {}

        // 5. Versi India baru (Moba Legends: 5v5!)
        try {
            activity.getPackageManager().getPackageInfo("com.mobilelegends.hwag", 0);
            return "com.mobilelegends.hwag";
        } catch (Exception ignored) {}

        // 6. Versi China (决胜巅峰)
        try {
            activity.getPackageManager().getPackageInfo("com.moonton.dfjs", 0);
            return "com.moonton.dfjs";
        } catch (Exception ignored) {}

        // 7. Versi Lite / Regional Afrika
        try {
            activity.getPackageManager().getPackageInfo("com.mobile.legends.ft", 0);
            return "com.mobile.legends.ft";
        } catch (Exception ignored) {}

        // Default Fallback: Jika tidak terdeteksi, kembalikan versi Global utama
        return "com.mobile.legends";
    }

    // ===============================
    // TARGET URI (FIXED: DISISIPI TRIK BYPASS %E2%80%8B)
    // ===============================
    public String GetDataUri() {
        String packageName = getMlPackage();
        String output = Build.MANUFACTURER.toUpperCase();
        String CyberPro;

        // UNTUK ANDROID 13, 14, 15, DAN 16 (WAJIB TRICK ZERO-WIDTH SPACE)
        if (Build.VERSION.SDK_INT >= 33) { 
            if (output.equals("HUAWEI") || output.equals("HONOR")) {
                CyberPro = "content://com.android.externalstorage.documents/tree/primary%3AAndroid%2Fdat%E2%80%8Ba/document/primary%3AAndroid%2Fdat%E2%80%8Ba%2F"
                        + packageName + "%2Ffiles%2Fdragon2017%2Fassets%2F";
            } else {
                // Menyisipkan %E2%80%8B di kata "dat a" agar sistem Android terkecoh
                CyberPro = "content://com.android.externalstorage.documents/tree/primary%3AAndroid%2Fdat%E2%80%8Ba/document/primary%3AAndroid%2Fdat%E2%80%8Ba%2F"
                        + packageName + "%2Ffiles%2Fdragon2017%2Fassets%2F";
            }
            return CyberPro;
        }

        // UNTUK ANDROID 11 DAN 12 BAWAHAN
        CyberPro = "content://com.android.externalstorage.documents/tree/primary%3AAndroid/document/primary%3AAndroid%2Fdata%2F"
                + packageName + "%2Ffiles%2Fdragon2017%2Fassets";
        return CyberPro;
    }

    // ===============================
    // HANDLE RESULT SAF
    // ===============================
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != NEW_FOLDER_REQUEST_CODE) return;

        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) {
            sp.edit().putString("DOWNLOAD_MODE", "").apply();
            Toast.makeText(activity, "Izin dibatalkan, silakan pilih mode kembali", Toast.LENGTH_SHORT).show();
            return; 
        }

        try {
            Uri muri = data.getData();
            final int takeFlags = data.getFlags() &
                    (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

            activity.getContentResolver().takePersistableUriPermission(muri, takeFlags);

            // Simpan FOLDER_URI murni
            sp.edit().putString("FOLDER_URI", muri.toString()).apply();

            DocumentFile root = DocumentFile.fromTreeUri(activity, muri);
            if (root == null) {
                Toast.makeText(activity, "Folder tidak valid", Toast.LENGTH_SHORT).show();
                return;
            }

            // BUAT FILE UJI COBA SEPERTI KODE PERTAMA ANDA YANG TEMBUS
            DocumentFile testFile = root.createFile("*/*", "CyberAlpha.PH");
            if (testFile == null) {
                Toast.makeText(activity, "Tidak bisa akses folder", Toast.LENGTH_SHORT).show();
                return;
            }

            Uri urit = testFile.getUri();
            
            // Simpan D_URI bersih (menghapus nama berkas contoh) agar sinkron dengan IsPermissionGranted
            sp.edit().putString("D_URI", urit.toString().replace("CyberAlpha.PH", "")).apply();

            // Hapus kembali berkas contohnya
            DocumentsContract.deleteDocument(activity.getContentResolver(), urit);

            Toast.makeText(activity, "Permission Granted ✅", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(activity, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
