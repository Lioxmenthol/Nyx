package com.nyx.tools;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;

public class AppOpenManager implements Application.ActivityLifecycleCallbacks {

    private static final String TAG = "OPEN_AD";

    // Ganti dengan ID asli kalau sudah production
    private static final String AD_UNIT_ID = "ca-app-pub-5321321373857819/9048924810";

    private AppOpenAd appOpenAd = null;
    private Activity currentActivity;

    private boolean isShowingAd = false;
    private boolean hasShownAd = false;   
    private boolean isColdStart = true;   

    private final Application application;

    public AppOpenManager(Application application) {
        this.application = application;
        this.application.registerActivityLifecycleCallbacks(this);

        ProcessLifecycleOwner.get().getLifecycle().addObserver(
                (LifecycleEventObserver) (source, event) -> {
                    if (event == Lifecycle.Event.ON_START) {
                        Log.d(TAG, "ON_START");

                        // 👑 KEMBALI KE ALUR ASLIMU: Langsung panggil loadAd secara instan tanpa antrean Handler!
                        if (isColdStart && !hasShownAd) {
                            loadAd();
                        }
                    }
                });
    }

    private void loadAd() {
        if (appOpenAd != null) return;

        Log.d(TAG, "Loading Ad...");

        AdRequest request = new AdRequest.Builder().build();

        AppOpenAd.load(
                application,
                AD_UNIT_ID,
                request,
                AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
                new AppOpenAd.AppOpenAdLoadCallback() {

                    @Override
                    public void onAdLoaded(AppOpenAd ad) {
                        Log.d(TAG, "Ad Loaded");
                        appOpenAd = ad;

                        // Di sini delay 700ms andalanmu sengaja diabaikan khusus saat dingin (cold start),
                        // karena pemanggilan tayang iklan sekarang dikendalikan penuh oleh callback SplashScreenActivity setelah selesai.
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError error) {
                        Log.d(TAG, "Ad Failed: " + error.getMessage());
                    }
                });
    }

    // 🔥 METHOD UTAMA BARU: Iklan wajib tayang dulu, setelah ditutup baru jalankan perpindahan halaman
    public void showAdWithCallback(Runnable onAdComplete) {
        if (appOpenAd == null || currentActivity == null || isShowingAd || hasShownAd || currentActivity.isFinishing()) {
            Log.d(TAG, "Ad tidak siap atau kriteria tidak terpenuhi, langsung lanjut ke halaman utama.");
            if (onAdComplete != null) {
                onAdComplete.run();
            }
            return;
        }

        hasShownAd = true;  

        // ✅ AMAN API 36: Full Path Package Callback untuk mengamankan tombol back Android 16
        appOpenAd.setFullScreenContentCallback(
                new com.google.android.gms.ads.FullScreenContentCallback() {

                    @Override
                    public void onAdShowedFullScreenContent() {
                        isShowingAd = true;
                        isColdStart = false;
                        Log.d(TAG, "Ad Showed");
                    }

                    @Override
                    public void onAdDismissedFullScreenContent() {
                        isShowingAd = false;
                        appOpenAd = null;
                        Log.d(TAG, "Ad Ditutup oleh User, jalankan pindah halaman.");
                        if (onAdComplete != null) {
                            onAdComplete.run(); // Memicu transisi ke MainActivity
                        }
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                        isShowingAd = false;
                        Log.d(TAG, "Gagal Tayang: " + adError.getMessage() + ", langsung pindah halaman.");
                        if (onAdComplete != null) {
                            onAdComplete.run(); // Jika gagal tayang, tetap pindah agar user tidak stuck di blackscreen
                        }
                    }
                });

        appOpenAd.show(currentActivity);
    }

    // Mempertahankan method showAd() bawaan agar tidak merusak kompabilitas sistem lifecyle luar jika ada
    public void showAd() {
        showAdWithCallback(null);
    }

    // ===== Activity Lifecycle (DIJAMIN AMAN DARI KEBOCORAN MEMORI RAM) =====

    @Override
    public void onActivityStarted(Activity activity) {
        currentActivity = activity;
    }

    @Override
    public void onActivityResumed(Activity activity) {
        currentActivity = activity;
    }

    @Override public void onActivityCreated(Activity activity, Bundle bundle) {}
    @Override public void onActivityPaused(Activity activity) {}
    
    @Override 
    public void onActivityStopped(Activity activity) {
        // ✅ PROTEKSI RAM: Putus referensi jika activity ini berhenti agar tidak mengendap di RAM
        if (currentActivity == activity) {
            currentActivity = null;
        }
    }
    
    @Override public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {}
    
    @Override 
    public void onActivityDestroyed(Activity activity) {
        // ✅ PROTEKSI RAM: Bersihkan total objek halaman saat dihancurkan oleh sistem Android 16
        if (currentActivity == activity) {
            currentActivity = null;
        }
    }
}
