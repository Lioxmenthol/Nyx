package com.nyx.tools;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.PowerManager;
import android.provider.DocumentsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.drawable.GradientDrawable;
import androidx.documentfile.provider.DocumentFile;
import com.kaopiz.kprogresshud.KProgressHUD;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class DefaultDownloader {
    private Activity activity;
    private SharedPreferences sp;
    private LayoutInflater inflater;
    private static boolean isDownloading = false;

    public DefaultDownloader(Activity activity) {
        this.activity = activity;
        this.inflater = activity.getLayoutInflater();
        // DISINKRONKAN: Membaca file preference default Sketchware agar D_URI terbaca sempurna
        this.sp = activity.getSharedPreferences(activity.getPackageName() + "_preferences", Activity.MODE_PRIVATE);
    }

    public void startDownload(String url, String zipName) {
        if (isDownloading) {
            Toast.makeText(activity, "Masih ada download yang berjalan...", Toast.LENGTH_SHORT).show();
            return;
        }
        new DownloadTask(url, zipName).execute();
    }

    private static String formatSize(long bytes) {
        if (bytes <= 0) return "0 B";
        String[] units = {"B", "KB", "MB", "GB"};
        int digit = 0; double size = bytes;
        while (size >= 1024 && digit < units.length - 1) { size /= 1024; digit++; }
        return String.format("%.2f %s", size, units[digit]);
    }

    private static String formatSpeed(long bytesPerSec) { return formatSize(bytesPerSec) + "/s"; }
    private static String formatTime(long second) { return String.format("%02d:%02d", second / 60, second % 60); }

    private class DownloadTask extends AsyncTask<ProgressData, ProgressData, String> {
        private String downloadUrl;
        private String zipName;
        private ProgressBar progressBar;
        private TextView txtTitle, txtPercent, txtSize, txtSpeed, txtEta;
        private KProgressHUD hud;
        private PowerManager.WakeLock wakeLock;

        DownloadTask(String url, String file) { this.downloadUrl = url; this.zipName = file; }

        @Override
        protected void onPreExecute() {
            isDownloading = true;
            PowerManager pm = (PowerManager) activity.getSystemService(Activity.POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DEFAULT:DownloadLock");
            wakeLock.acquire(10 * 60 * 1000L);

            View v = inflater.inflate(R.layout.ext, null);
            LinearLayout linear = v.findViewById(R.id.linear2);
            progressBar = v.findViewById(R.id.progressbar1);
            txtTitle = v.findViewById(R.id.txtTitle);
            txtPercent = v.findViewById(R.id.textviewer);
            txtSize = v.findViewById(R.id.txtSize);
            txtSpeed = v.findViewById(R.id.txtSpeed);
            txtEta = v.findViewById(R.id.txtEta);

            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xFF000000); bg.setCornerRadius(30); bg.setStroke(4, 0xFFFFFFFF);
            linear.setBackground(bg);
            progressBar.setMax(100); progressBar.setProgress(0);
            // ======================================================================
            // 🎨 LAYER BARU: BIKIN PROGRESS BAR BIRU CYAN + STROKE PUTIH
            // ======================================================================
            // 1. Latar belakang kosong (Abu-abu pudar + Stroke putih murni 3px)
            android.graphics.drawable.GradientDrawable progressBg = new android.graphics.drawable.GradientDrawable();
            progressBg.setColor(0x33FFFFFF); 
            progressBg.setStroke(2, 0xFFFFFFFF); 
            progressBg.setCornerRadius(10); 

            // 2. Isi progress berjalan (Warna Biru Cyan Terang #00E5FF)
            android.graphics.drawable.GradientDrawable progressFill = new android.graphics.drawable.GradientDrawable();
            progressFill.setColor(0xFF00E5FF); 
            progressFill.setCornerRadius(10);

            // 3. Gabungkan ke dalam satu kesatuan objek baru
            android.graphics.drawable.Drawable[] layers = new android.graphics.drawable.Drawable[] {
                progressBg,
                new android.graphics.drawable.ScaleDrawable(progressFill, android.view.Gravity.LEFT, 1.0f, -1.0f)
            };

            android.graphics.drawable.LayerDrawable finalDrawable = new android.graphics.drawable.LayerDrawable(layers);
            finalDrawable.setId(0, android.R.id.background);
            finalDrawable.setId(1, android.R.id.progress);

            // 4. Pasang ke ProgressBar
            progressBar.setProgressDrawable(finalDrawable);
            // ======================================================================

            txtTitle.setText("Preparing..."); txtPercent.setText("0%");
            txtSize.setText("0 B / 0 B"); txtSpeed.setText("0 KB/s"); txtEta.setText("Remaining --:--");

            hud = KProgressHUD.create(activity).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setCustomView(v).setCancellable(false);
            hud.show();
            
            try {
                android.view.ViewParent vp = v.getParent();
                while (vp instanceof android.view.View) {
                    android.view.View parentView = (android.view.View) vp;
                    parentView.setBackgroundColor(android.graphics.Color.TRANSPARENT);
                    parentView.setPadding(0, 0, 0, 0);
                    vp = parentView.getParent();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(ProgressData... params) {
            try {
                String uriString = sp.getString("D_URI", "");
                if (uriString.isEmpty()) return "Permission tidak valid";

                Uri treeUri = Uri.parse(uriString);
                DocumentFile root = DocumentFile.fromTreeUri(activity, treeUri);
                if (root == null) return "Folder tidak valid";

                publishProgress(ProgressData.createTitleUpdate("Connecting..."));
                HttpURLConnection conn = (HttpURLConnection) new URL(downloadUrl).openConnection();
                conn.setConnectTimeout(15000); conn.setReadTimeout(15000); conn.connect();
                if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) return "HTTP " + conn.getResponseCode();

                long totalBytes = conn.getContentLengthLong();
                InputStream input = conn.getInputStream();

                // OPTIMASI 1: DOWNLOAD KE INTERNAL CACHE (BUKAN DI SAF)
                java.io.File localCacheDir = activity.getCacheDir();
                java.io.File tempZipFile = new java.io.File(localCacheDir, zipName);
                
                java.io.FileOutputStream out = new java.io.FileOutputStream(tempZipFile);
                byte[] buffer = new byte[131072]; // 128KB
                int len; long downloadedBytes = 0; long lastTime = System.currentTimeMillis(); long lastBytes = 0;

                publishProgress(ProgressData.createTitleUpdate("Downloading..."));
                while ((len = input.read(buffer)) != -1) {
                    out.write(buffer, 0, len);
                    downloadedBytes += len;
                    long now = System.currentTimeMillis();
                    if (now - lastTime >= 1000) {
                        long speed = downloadedBytes - lastBytes;
                        long eta = (speed > 0) ? (totalBytes - downloadedBytes) / speed : 0;
                        int percent = (totalBytes > 0) ? (int) (downloadedBytes * 100L / totalBytes) : 0;
                        publishProgress(ProgressData.createProgressUpdate(percent, downloadedBytes, totalBytes, speed, eta));
                        lastBytes = downloadedBytes; lastTime = now;
                    }
                }
                out.flush(); out.close(); input.close(); conn.disconnect();

                publishProgress(ProgressData.createProgressUpdate(100, totalBytes, totalBytes, 0, 0));
                publishProgress(ProgressData.createTitleUpdate("Extracting..."));

                // OPTIMASI 2: EKSTRAKSI SECARA LOKAL (SANGAT CEPAT)
                java.io.File localExtractDir = new java.io.File(localCacheDir, "extracted_skin_" + System.currentTimeMillis());
                if (!localExtractDir.exists()) localExtractDir.mkdirs();

                java.io.FileInputStream fis = new java.io.FileInputStream(tempZipFile);
                ZipInputStream zis = new ZipInputStream(new java.io.BufferedInputStream(fis, 131072));
                ZipEntry entry;

                while ((entry = zis.getNextEntry()) != null) {
                    java.io.File outFile = new java.io.File(localExtractDir, entry.getName());
                    if (entry.isDirectory()) {
                        outFile.mkdirs();
                    } else {
                        java.io.File parent = outFile.getParentFile();
                        if (parent != null && !parent.exists()) parent.mkdirs();
                        
                        java.io.BufferedOutputStream bos = new java.io.BufferedOutputStream(new java.io.FileOutputStream(outFile), 131072);
                        int count;
                        while ((count = zis.read(buffer)) != -1) { bos.write(buffer, 0, count); }
                        bos.flush(); bos.close();
                    }
                    zis.closeEntry();
                }
                zis.close(); fis.close();
                tempZipFile.delete(); // Hapus zip temp setelah diekstrak

                // OPTIMASI 3: SALIN HASIL EKSTRAKSI KE SAF SEKALIGUS
                publishProgress(ProgressData.createTitleUpdate("Proccess..."));
                int[] fileCounter = new int[]{0};
                
                // Memanggil fungsi salin yang berada di dalam AsyncTask agar sinkron dengan UI
                copyLocalFolderToSAF(localExtractDir, root, fileCounter);

                // Bersihkan folder ekstrak lokal setelah selesai
                deleteLocalFolder(localExtractDir);

                return "OK";
            } catch (Exception e) { return e.toString(); }
        }

        // Fungsi pembantu untuk memindahkan struktur folder lokal ke SAF secara efisien
        private void copyLocalFolderToSAF(java.io.File localDir, DocumentFile safDir, int[] counter) throws Exception {
    java.io.File[] files = localDir.listFiles();
    if (files == null) return;

    for (java.io.File file : files) {
        if (file.isDirectory()) {
            DocumentFile nextSafDir = safDir.findFile(file.getName());
            if (nextSafDir == null || !nextSafDir.isDirectory()) {
                nextSafDir = safDir.createDirectory(file.getName());
            }
            if (nextSafDir != null) {
                copyLocalFolderToSAF(file, nextSafDir, counter);
            }
        } else {
            // ========================================================
            // METODE ZARCHIVER: TEMBAK TARGET & TIMPA LANGSUNG (wt)
            // ========================================================
            Uri parentUri = safDir.getUri();
            String parentDocId = DocumentsContract.getDocumentId(parentUri);
            
            // Susun ID file target secara spesifik
            String childDocId = parentDocId + "/" + Uri.encode(file.getName());

            Uri fileTargetUri = DocumentsContract.buildDocumentUriUsingTree(parentUri, childDocId);

            OutputStream out = null;
            try {
                // Trik Utama: Buka file target dengan mode "wt" (Write-Truncate)
                // Ini akan langsung menimpa isi file lama tanpa menghapus filenya dari sistem
                out = activity.getContentResolver().openOutputStream(fileTargetUri, "wt");
            } catch (Exception e) {
                // Jika file belum ada di folder target, sistem akan memicu error.
                // Maka, kita buat file baru secara normal di sini.
                DocumentFile newSafFile = safDir.createFile("*/*", file.getName());
                if (newSafFile != null) {
                    out = activity.getContentResolver().openOutputStream(newSafFile.getUri());
                }
            }

            if (out != null) {
                java.io.FileInputStream in = new java.io.FileInputStream(file);
                java.io.BufferedOutputStream bos = new java.io.BufferedOutputStream(out, 131072); // Buffer 128KB
                
                byte[] buf = new byte[131072];
                int len;
                while ((len = in.read(buf)) != -1) { 
                    bos.write(buf, 0, len); 
                }
                bos.flush(); bos.close(); out.close(); in.close();
                
                counter[0]++;
                publishProgress(ProgressData.createExtractUpdate(-1, counter[0], 0));
            }
        }
    }
}


        // Fungsi rekursif untuk menghapus folder cache lokal
        private void deleteLocalFolder(java.io.File folder) {
            java.io.File[] files = folder.listFiles();
            if (files != null) {
                for (java.io.File f : files) {
                    if (f.isDirectory()) deleteLocalFolder(f);
                    else f.delete();
                }
            }
            folder.delete();
        }

        @Override
        protected void onProgressUpdate(ProgressData... values) {
            ProgressData data = values[0];
            if (data.type == ProgressData.TYPE_TITLE) { txtTitle.setText(data.title); } 
            else if (data.type == ProgressData.TYPE_DOWNLOAD) {
                progressBar.setIndeterminate(false);
                progressBar.setProgress(data.percent); txtPercent.setText(data.percent + "%");
                txtSize.setText(formatSize(data.current) + " / " + formatSize(data.total));
                txtSpeed.setText(formatSpeed(data.speed)); txtEta.setText("Remaining " + formatTime(data.eta));
            } 
            else if (data.type == ProgressData.TYPE_EXTRACT) {
                progressBar.setIndeterminate(true); // Membuat bar bergerak dinamis konstan otomatis
                txtPercent.setText("Download");
                txtSize.setText("Installing: " + data.current + " Files...");
                txtSpeed.setText("Extracting..."); txtEta.setText("");
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (hud != null && hud.isShowing()) hud.dismiss();
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
            isDownloading = false;
            if (result.equals("OK")) { Toast.makeText(activity, "Done / Selesai\u2705", Toast.LENGTH_LONG).show(); } 
            else { Toast.makeText(activity, result, Toast.LENGTH_LONG).show(); }
        }
    }

    private static class ProgressData {
        static final int TYPE_TITLE = 0; static final int TYPE_DOWNLOAD = 1; static final int TYPE_EXTRACT = 2;
        int type; String title; int percent; long current; long total; long speed; long eta;

        static ProgressData createTitleUpdate(String title) { ProgressData d = new ProgressData(); d.type = TYPE_TITLE; d.title = title; return d; }
        static ProgressData createProgressUpdate(int percent, long current, long total, long speed, long eta) { 
            ProgressData d = new ProgressData(); d.type = TYPE_DOWNLOAD; d.percent = percent; d.current = current; d.total = total; d.speed = speed; d.eta = eta; return d; 
        }
        static ProgressData createExtractUpdate(int percent, long currentFiles, long totalFiles) {
            ProgressData d = new ProgressData(); d.type = TYPE_EXTRACT; d.percent = percent; d.current = currentFiles; d.total = totalFiles; return d;
        }
    }
}
